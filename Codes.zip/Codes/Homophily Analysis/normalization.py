# -*- coding: utf-8 -*-
"""
Created on Sun Nov 26 09:20:27 2017

@author: Lenovo
"""
import csv
import pandas as pd
import json
import operator

#importing the dataset
dataset = pd.read_csv('Scores_Faith.csv')
dataset.columns = ['Openness','Conscientiousness','Extroversion','Agreeableness','Neuroticsm']
dataset.head()

#Scaling
from sklearn.preprocessing import scale
import numpy as np
X_Scale = scale(dataset[['Openness','Conscientiousness','Extroversion','Agreeableness','Neuroticsm']])
print (X_Scale)
#with open ('Scaled_Personality.csv','w') as sp:
np.savetxt('Scaled_Faith_Personality.csv',X_Scale,delimiter = ',',fmt='%1.4e')

#Zscore Normalization
with open ('Scaled_Faith_Personality_Final.csv','w+') as writer:
    with open ('Scaled_Faith_Personality.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            zscore_list = []
            row = [float(i) for i in row]
            print(row)
            minimum = min(row)
            maximum = max(row)
            for each in row:
                zscore = (each - minimum)/(maximum - minimum)
                #print(zscore)
                zscore_list.append(zscore)
            print (zscore_list)
            index, value = max(enumerate(zscore_list), key=operator.itemgetter(1))
            writer.write(json.dumps(zscore_list)+str(index)+"\n")
            print(index)
            zscore_list.clear()
            
