#encoding=utf-8
from nltk.stem.porter import PorterStemmer
pt = PorterStemmer()

liwc_dict = {}

featurelist = []

import csv
import sys
csv.field_size_limit(sys.maxsize)
import nltk
from nltk.tokenize import word_tokenize
import numpy as np

#clf = svm.SVC(kernel='linear', probability=True)
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
import pickle
vect_of_vector=[]
list_classes=[]
nrc_anger=[]
nrc_anticipation=[]
nrc_disgust=[]
nrc_fear=[]
nrc_joy=[]
nrc_sadness=[]
nrc_surprise=[]
nrc_trust=[]
nrc_positive=[]
nrc_negative=[]
anger=[]
disgust=[]
fear=[]
joy=[]
sadness=[]
surprise=[]
bag_list=['you', 'the', 'that', 'for', 'and', 'your', 'have', 'can', 'What', 'are', 'need', 'with', 'apartment', 'about', 'will', 'You', 'this', "I'm", 'there', 'know', 'was', 'out', 'get', 'How', 'car', 'like', 'help', 'would', "I'll", 'Yes', 'not', "don't", 'but', 'what', 'think', 'all', 'take', 'good', 'rent', 'going', 'just', 'any', 'The', "That's", 'bus', 'Are', 'much', 'see', 'really', 'here', 'one', 'right', 'problem', 'pay', 'want', 'sure', 'Can', 'make', 'when', 'did', 'over', 'look', 'check', 'time', 'how', 'they', 'been', 'should', 'Well', 'move', 'them', 'today', 'find', 'This', "It's", 'month', 'could', 'job', 'use', 'where', 'That', 'come', 'tell', 'There', 'more', 'great', 'give', 'lot', 'very', 'key', "can't", 'our', 'new', 'late', 'next', 'When', "didn't", 'from', 'work', 'unemployment', "What's", 'some', 'last', 'now', 'few', 'room', 'too', 'Did', 'anything', 'something', 'only', 'pass', 'two', 'information', 'fine', 'questions', 'then', "I've", 'has', 'may', "it's", 'other', "you're", 'before', 'manager', 'might', 'call', 'first', 'Hello', 'day', 'got', 'Thank', 'people', 'Just', 'Okay', 'does', 'form', 'turn', 'because', 'days', 'moving', 'stop', 'than', 'were', 'many', 'ask', 'else', 'Why', 'parking', 'money', 'house', 'into', 'long', 'why', 'office', 'Where', 'insurance', 'back', 'let', 'Have', 'street', 'hear', 'Your', 'found', 'available', 'off', 'All', 'way', 'still', 'looking', 'who', 'appreciate', 'down', 'laundry', 'put', 'fees', 'love', 'Would', 'keep', 'little', 'interested', 'wondering', 'place', 'around', 'building', 'hours', 'okay', 'Thanks', 'week', 'keys', 'buy', 'EDD', 'talk', 'notice', 'pretty', 'Could', 'nice', 'Great', 'Will', 'sign', 'years', 'show', 'Sure', 'thinking', 'park', 'agreement', 'application', 'away', 'had', 'cost', 'course', 'mail', 'interview', 'living', 'tomorrow', 'saw', 'period', 'glad', 'kind', 'Now', 'special', "doesn't", 'their', 'calling', 'student', 'sorry', 'phone', 'Claim', 'Continued', 'rental', 'each', 'things', 'everything', 'Form', 'price', 'drive', 'being', 'fill', 'neighborhood', "that's", 'idea', 'question', 'disposal', 'send', 'doing', 'Good', 'stay', 'roommate', 'They', 'speak', 'Tell', 'Maybe', 'happened', 'But', 'area', 'again', "Don't", 'number', 'problems', 'Nicole', 'able', 'bring', 'must', 'ticket', 'wanted', 'loud', "there's", 'collect', 'happy', 'live', 'online', 'someone', "You're", 'ESL', "isn't", 'lease', 'understand', 'fee', 'meet', 'hope', 'Altadena', 'well', 'thought', 'every', 'friend', 'catch', 'neighbors', 'deposit', 'care', 'always', 'please', 'Wednesday', "won't", 'local', 'appointment', 'thing', 'damage', 'wrong', "we'll", 'mind', 'detectors', '']
affection=['care','kindness','case','closeness','love','like','liking','concern','desire','passion','crush','devotion','feeling','warmth','friendship']
apology=['acknowledgement','concession','justification','defence','confession','excuse','explanation','sorry','forgive','apologise','sad', 'regret', 'remorse', 'contrite', 'repentant', 'guilty']
appreciate=['acknowledge','enjoy','welcome']
wh_words=['what','when','why','where','which','who','whom','whose']
#def speech_act_prob(sentence):


def Make_lexicon():

    count=1
    count_new=1

    '''with open("bag_of_words.txt","r") as pt:
        bag_list = pt.read().split("\n")
        #print bag_list   '''
    with open("anger.txt","r") as pt:
        word_list = pt.read().split("\n")
        for x in word_list:
            trimmed=x.replace(x[:11], '')
            trimmed_list=trimmed.split(' ')
            for trim in trimmed_list:
                anger.append(trim)
    with open("disgust.txt","r") as pt:
        word_list = pt.read().split("\n")
        for x in word_list:
            trimmed=x.replace(x[:11], '')
            trimmed_list=trimmed.split(' ')
            for trim in trimmed_list:
                disgust.append(trim)
    with open("fear.txt","r") as pt:
        word_list = pt.read().split("\n")
        for x in word_list:
            trimmed=x.replace(x[:11], '')
            trimmed_list=trimmed.split(' ')
            for trim in trimmed_list:
                fear.append(trim)
    with open("joy.txt","r") as pt:
        word_list = pt.read().split("\n")
        for x in word_list:
            trimmed=x.replace(x[:11], '')
            trimmed_list=trimmed.split(' ')
            for trim in trimmed_list:
                joy.append(trim)
    with open("sadness.txt","r") as pt:
        word_list = pt.read().split("\n")
        for x in word_list:
            trimmed=x.replace(x[:11], '')
            trimmed_list=trimmed.split(' ')
            for trim in trimmed_list:
                sadness.append(trim)
    with open("surprise.txt","r") as pt:
        word_list = pt.read().split("\n")
        for x in word_list:
            trimmed=x.replace(x[:11], '')
            trimmed_list=trimmed.split(' ')
            for trim in trimmed_list:
                surprise.append(trim)


    with open("nrc.csv") as nrc:
        csv_reader = csv.reader(nrc)
        for row in csv_reader:
            if row[1]=="anger":
                if row[2]==1:
                    nrc_anger.append(row[0])
                    #print row[0]
            if row[1]=="anticipation":
                if row[2]=="1":
                    nrc_anticipation.append(row[0])
            if row[1]=="disgust":
                if row[2]=="1":
                    nrc_disgust.append(row[0])
            if row[1]=="fear":
                if row[2]=="1":
                    nrc_fear.append(row[0])
            if row[1]=="joy":
                if row[2]=="1":
                    nrc_joy.append(row[0])
            if row[1]=="sadness":
                if row[2]=="1":
                        nrc_sadness.append(row[0])
            if row[1]=="surprise":
                if row[2]=="1":
                    nrc_surprise.append(row[0])
            if row[1]=="trust":
                if row[2]=="1":
                    nrc_trust.append(row[0])
            if row[1]=="positive":
                if row[2]=="1":
                    nrc_positive.append(row[0])
            if row[1]=="negative":
                if row[2]=="1":
                    nrc_negative.append(row[0])

def speech_act_prob(sentence):
    #print bag_list
    vector=[]
    y=[]

    word_list=word_tokenize(sentence)
    for words in bag_list:
        #print words
        if words in word_list:
            vector.append(word_list.count(words))
        else:
            vector.append("0")
    if "?" in word_list:
        vector.append(word_list.count("?"))
    else:
        vector.append("0")
    if bool(set(wh_words) & set(word_list)):
        s_sum=0
        new_list=list(set(wh_words).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
    else:
        vector.append("0")
    if "thanks" in word_list or "thank" in word_list:
        total_cou=word_list.count("thank")+word_list.count("thanks")
        vector.append(str(total_cou))
    else:
        vector.append("0")
    text= word_tokenize(sentence)
    Tagged_words=nltk.pos_tag(text)
    Tagged_words=dict(Tagged_words)
    values= Tagged_words.values()
    Verb_count=0
    Noun_count=0
    Adjective_count=0
    Adverb_count=0
    Pronoun_count=0
    Preposition_count=0
    for tags in values:
            if tags.startswith('V'):
                Verb_count=Verb_count+1
            if tags.startswith('N'):
                Noun_count=Noun_count+1
            if tags.startswith('J'):
                Adjective_count=Adjective_count + 1
            if tags.startswith('RB'):
                Adverb_count=Adverb_count + 1
            if tags.startswith('PRP'):
                Pronoun_count=Pronoun_count+1
            if tags.startswith('IN'):
                Preposition_count=Preposition_count+1
    vector.append(Verb_count)
    vector.append(Noun_count)
    vector.append(Adjective_count)
    vector.append(Adverb_count)
    vector.append(Pronoun_count)
    vector.append(Preposition_count)
    #vector.append(row[1])
    if bool(set(nrc_anger) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_anger).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
    else:
        vector.append("0")
    if bool(set(nrc_anticipation) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_anticipation).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
    else:
        vector.append("0")
    if bool(set(nrc_disgust) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_disgust).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(nrc_fear) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_fear).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(nrc_joy) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_joy).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(nrc_sadness) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_sadness).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(nrc_surprise) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_surprise).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(nrc_trust) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_trust).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(nrc_positive) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_positive).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
        #print "1"
    else:
        vector.append("0")
    if bool(set(nrc_negative) & set(word_list)):
        s_sum=0
        new_list=list(set(nrc_negative).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(affection) & set(word_list)):
        s_sum=0
        new_list=list(set(affection).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(apology) & set(word_list)):
        s_sum=0
        new_list=list(set(apology).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(appreciate) & set(word_list)):
        s_sum=0
        new_list=list(set(appreciate).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(anger) & set(word_list)):
        s_sum=0
        new_list=list(set(anger).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(disgust) & set(word_list)):
        s_sum=0
        new_list=list(set(disgust).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(fear) & set(word_list)):
        s_sum=0
        new_list=list(set(fear).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(joy) & set(word_list)):
        s_sum=0
        new_list=list(set(joy).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(sadness) & set(word_list)):
        s_sum=0
        new_list=list(set(sadness).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    if bool(set(surprise) & set(word_list)):
        s_sum=0
        new_list=list(set(surprise).intersection(word_list))
        for i in new_list:
            s_sum=s_sum+word_list.count(i)
        vector.append(str(s_sum))
        #vector.append("1")
    else:
        vector.append("0")
    #print vector
    #y.append(row[1])

    #vect_of_vector.append(vector)
    with open('speech_act.pkl', 'rb') as fid:
        predictor =  pickle.load(fid)
    new =np.asarray(vector)
    new =new.reshape(1,-1)
    #new2= new.tolist()[0]
    #print new2
    #print len(new2)
    x = predictor.predict_proba(new).tolist()[0]
    #x=new2
    return x


with open("LIWC.all.txt") as liwc_file:
    lines = liwc_file.read().split("\n")

    try:
        for li in lines :
            word,feature = li.split(" ,")
            print (word)
            if '*' in word:
                word = word[:-1]
                print (word)
            liwc_dict[pt.stem(word)] = feature
            if feature not in featurelist:
                featurelist.append(feature)

    except ValueError:
        pass

sensicon_path = 'Sensicon_data.txt'
sense_map = {}

featurelist.append('S1')
featurelist.append('S2')
featurelist.append('S3')
featurelist.append('S4')
featurelist.append('S5')

with open(sensicon_path,'r') as df:
    sense_list = df.read().split("\n")

    for x in sense_list:
        sense_word = x.split("__")[0]
        y = x.split()
        temp = []
        try:
            temp.append(float(y[1]))
            temp.append(float(y[2]))
            temp.append(float(y[3]))
            temp.append(float(y[4]))
            temp.append(float(y[5]))
            sense_map[pt.stem(sense_word)] = temp
        except IndexError:
            break

inquirermap = {}

with open('inquirerbasic.csv','r') as dg:
    mycsvreader = csv.reader(dg)
    dd = 0
    for row in mycsvreader:
        if dd==0:
            for i in range(2,len(row)):
                featurelist.append('H'+str(i))
        else:
            word = ''
            if '#' in row[0]:
                word = row[0][:-2].lower()
            else:
                word = row[0].lower()
            if word not in inquirermap:
                inquirermap[word.strip()] = []
            for i in range(2,len(row)):
                if row[i] != '':
                    inquirermap[word.strip()].append('H'+str(i))
        dd = dd + 1


from nltk.tokenize import TweetTokenizer
tknzr = TweetTokenizer()

import csv
import sys

data_matrix = []

label = []
for i in range(5):
    label.append([])

count = 0

csv.field_size_limit(sys.maxsize)

userid = []

finaldata = {}

import codecs
'''
with codecs.open("3.csv", 'r', 'utf-8', 'surrogateescape') as rd:
    mycsvreader = csv.reader(rd)
    #print (mycsvreader)
    for row in mycsvreader:
        if row[0] not in finaldata:
            try:
                finaldata[row[0]] = row[1]
            except:
                print ("List index out of range")
        else:
            finaldata[row[0]] += "\n" + row[1]
'''

with codecs.open("status_id_3.txt", 'r', 'utf-8', 'surrogateescape') as rd:
    mycsvreader = csv.reader(rd)
    #print (mycsvreader)
    for row in mycsvreader:
        if row[0] not in finaldata:
            finaldata[row[0]] = row[1]
        else:
            finaldata[row[0]] += "\n" + row[1]

Make_lexicon()

print (len(liwc_dict))
print (len(inquirermap))
print (len(sense_map))

import re
with  codecs.open("status_id_3.txt", 'r', 'utf-8', 'surrogateescape') as rd:
    mycsvreader = csv.reader(rd)
    count = 0
    for row in mycsvreader:

        myfeatures = {}
        myfeatures["S1"] = 0.0
        myfeatures["S2"] = 0.0
        myfeatures["S3"] = 0.0
        myfeatures["S4"] = 0.0
        myfeatures["S5"] = 0.0

        if row[0] in userid:
            continue
        else:
            count += 1
            print (count)
            userid.append(row[0])
        print (row[0])
        temdata = finaldata[row[0]].lower()

        temdata = re.sub(r"http\S+","",temdata)
        temdata = re.sub(r"#\S+","",temdata)
        temdata = re.sub(r"@\S+","",temdata)

        wordlist = tknzr.tokenize(temdata)
        for x in wordlist:
            temp = x.strip()
            stemmed_temp = pt.stem(temp)

            if len(temp) > 2:
                if temp in liwc_dict:
                    if liwc_dict[temp] in myfeatures:
                        myfeatures[liwc_dict[temp]]+= 1.0
                    else:
                        myfeatures[liwc_dict[temp]] = 1.0
                elif stemmed_temp in liwc_dict:
                    if liwc_dict[stemmed_temp] in myfeatures:
                        myfeatures[liwc_dict[stemmed_temp]]+= 1.0
                    else:
                        myfeatures[liwc_dict[stemmed_temp]] = 1.0

                if temp in sense_map:
                    myfeatures["S1"] += sense_map[temp][0]
                    myfeatures["S2"] += sense_map[temp][1]
                    myfeatures["S3"] += sense_map[temp][2]
                    myfeatures["S4"] += sense_map[temp][3]
                    myfeatures["S5"] += sense_map[temp][4]
                elif stemmed_temp in sense_map:
                    myfeatures["S1"] += sense_map[stemmed_temp][0]
                    myfeatures["S2"] += sense_map[stemmed_temp][1]
                    myfeatures["S3"] += sense_map[stemmed_temp][2]
                    myfeatures["S4"] += sense_map[stemmed_temp][3]
                    myfeatures["S5"] += sense_map[stemmed_temp][4]

                if temp in inquirermap:
                    for gifeat in inquirermap[temp]:
                        if gifeat in myfeatures:
                            myfeatures[gifeat] += 1.0
                        else:
                            myfeatures[gifeat] = 1.0
                elif stemmed_temp in inquirermap:
                    for gifeat in inquirermap[stemmed_temp]:
                        if gifeat in myfeatures:
                            myfeatures[gifeat] += 1.0
                        else:
                            myfeatures[gifeat] = 1.0


        local_featurelist=[]

        for x in featurelist:
            if x in myfeatures:
                try:
                    if (len(wordlist) == 0):
                        local_featurelist.append(myfeatures[x]/1)
                    else:		
                        local_featurelist.append(myfeatures[x]/len(wordlist))
                except:
                    print ("Divide by Zero")
            else:
                local_featurelist.append(0.0)

        local_featurelist += speech_act_prob(finaldata[row[0]].lower())
        #print (local_featurelist)

        data_matrix.append(local_featurelist)

with open ('prediction_ids_30s.csv','w') as writer:
    for ids in userid:
        writer.write(ids+"\n")


count =0;
for tel in data_matrix: 
    count = count+1	
    print (count,"---",tel)
del inquirermap
del tknzr
del sense_map
del liwc_dict

'''
# training
from sklearn import svm

list = []
#agreeable_list = []
#conscientiousness_list = []
#extroversion_list = []
openness_list = []
#neurotic_list = []

with open('/home/research/Desktop/Age_Classifier/labels_10.txt', 'r') as fp:  
	for line in fp:
       		#print(line)
		list.append(line)
for l in list:
	l = l.replace("\n","")
	openness_list.append(l)	
print("data",len(data_matrix))
print ("class",len(openness_list))


train_x = np.asarray(data_matrix,dtype = object)
#np.asarray of class
#read the file in to list called class_personality  then convet the class_personality using  train_y = np.asarray(class_personality)
# then comment train_y =["y","n","y","y"]

train_y = np.asarray(openness_list,dtype = object)
#train_y =["y","n","y","y"]
model = svm.SVC(kernel='linear',C=1,probability=True,gamma=1)
model.fit(train_x ,train_y)
filename ='10s_model.sav'
pickle.dump(model, open(filename, 'wb'),protocol = 2)


loaded_model = pickle.load(open(filename, 'rb'))
result = loaded_model.score(train_x, train_y)
print(result)
'''

#classification
test_filename = '30s_model.sav'
test_model = pickle.load(open(test_filename,'rb'))
predicted_result = test_model.predict_proba(data_matrix)
predicted_result_class = test_model.predict(data_matrix)

output = open("test_scores_30s.csv","w+") 
for k in range(len(predicted_result_class)):
    #print (predicted_result_class[k],predicted_result[k])
    #print (predicted_result_class[k])
    data = str(predicted_result_class[k])+","+str(predicted_result[k])
    #data = str(predicted_result_class[k])
    print (data)
    output.write (data)

