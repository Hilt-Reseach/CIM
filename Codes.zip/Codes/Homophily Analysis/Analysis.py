# -*- coding: utf-8 -*-
"""
Created on Thu Dec 28 08:02:36 2017

@author: Lenovo
"""

import csv
import os


#Gettiing unique user list

user = []
with open ('unique_user_list.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        print(row)
        if row not in user:
            user.append(row)
    print(len(user))

#Creating the id_personality dictionary
id_pers = {}
with open ('id_pers.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        print("id = "+row[0]+" personality = "+row[1])
        id_pers[row[0]] = row[1]
            
for key, value in id_pers.items():
    print(key+" ---- "+value)

#Looping through the directories.
directory = "F:\Categorized Network\Personality\Followers"
r = []
    
def list_files(dir):
    for root, dirs, files in os.walk(dir):
        for name in files:
            r.append(os.path.join(root, name))
    return r
list_files(directory)

for files in r:
    print(files)
print(len(r))

#Read the followers id file
id_pers_clean = {}
with open ('Followers_Clean_ids.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        print("id = "+row[0]+" personality = "+row[1])
        id_pers_clean[row[0]] = row[1]
            
for key, value in id_pers_clean.items():
    print(key+" ---- "+value)

print (len(id_pers_clean))

#Creating the friends network
with open ('Network_Friends.csv','w') as writer:
    with open ('Followers_Clean.csv','r') as f:
        reader = csv.reader(f,delimiter = '~')
        for row in reader:
            print (row)
            friends = row[1].split(",")
            for friend in friends:
                print (row[0]+" ---- "+friend)
                writer.write(row[0]+" ---- "+friend+"\n")

#Creating the relatives network
with open ('Network_Relatives.csv','w') as writer:
    with open ('Followers_Clean.csv','r') as f:
        reader = csv.reader(f,delimiter = '~')
        for row in reader:
            print (row)
            relatives = row[2].split(",")
            for relative in relatives:
                print (row[0]+" ---- "+relative)    
                writer.write(row[0]+" ---- "+relative+"\n")
        
#Creating the colleagues network
with open ('Network_Colleagues.csv','w') as writer:
    with open ('Followers_Clean.csv','r') as f:
        reader = csv.reader(f,delimiter = '~')
        for row in reader:
            print (row)
            colleagues = row[3].split(",")
            for colleague in colleagues:
                print (row[0]+" ---- "+colleague)    
                writer.write(row[0]+" ---- "+colleague+"\n")

#Creating the others network
with open ('Network_Others.csv','w') as writer:
    with open ('Followers_Clean.csv','r') as f:
        reader = csv.reader(f,delimiter = '~')
        for row in reader:
            print (row)
            others = row[4].split(",")
            for other in others:
                #print (row[0]+" ---- "+other) 
                other_clean = other.split(":")
                print (row[0]+" ---- "+other_clean[0]) 
                writer.write(row[0]+" ---- "+other_clean[0]+"\n")
                
#Converting friends names to ids
with open ('Network_Friends_ids.csv','w') as writer:
    with open ('Network_Friends.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers_clean):
                source = row[0].replace(row[0],id_pers_clean.get(row[0]))
                print (source + " --- " + row[1])
            if(row[1] in id_pers_clean):
                target = row[1].replace(row[1],id_pers_clean.get(row[1]))
                print (source + " --- " + target)
                writer.write(source + "," + target + "\n")

#Converting relatives names to ids                
with open ('Network_Relatives_ids.csv','w') as writer:
    with open ('Network_Relatives.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers_clean):
                source = row[0].replace(row[0],id_pers_clean.get(row[0]))
                print (source + " --- " + row[1])
            if(row[1] in id_pers_clean):
                target = row[1].replace(row[1],id_pers_clean.get(row[1]))
                print (source + " --- " + target)
                writer.write(source + "," + target + "\n")

#Converting colleagues names to ids                
with open ('Network_Colleagues_ids.csv','w') as writer:
    with open ('Network_Colleagues.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers_clean):
                source = row[0].replace(row[0],id_pers_clean.get(row[0]))
                print (source + " --- " + row[1])
            if(row[1] in id_pers_clean):
                target = row[1].replace(row[1],id_pers_clean.get(row[1]))
                print (source + " --- " + target)
                writer.write(source + "," + target + "\n")
                
#Converting others names to ids                
with open ('Network_Others_ids.csv','w') as writer:
    with open ('Network_Others.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers_clean):
                source = row[0].replace(row[0],id_pers_clean.get(row[0]))
                print (source + " --- " + row[1])
            if(row[1] in id_pers_clean):
                target = row[1].replace(row[1],id_pers_clean.get(row[1]))
                print (source + " --- " + target)
                writer.write(source + "," + target + "\n")

# Personality for Friends Network
with open ("Personality_Friends.csv",'w') as writer:
    with open("Network_Friends_ids.csv",'r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers):
                source = row[0] + "_" + id_pers.get(row[0])
                #print (source)
            if(row[1] in id_pers):
                target = row[1] + "_" + id_pers.get(row[1])
                print (source + "," + target)
                writer.write(source + "," + target + "\n")
                
# Personality for Relatives Network
with open ("Personality_Relatives.csv",'w') as writer:
    with open("Network_Relatives_ids.csv",'r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers):
                source = row[0] + "_" + id_pers.get(row[0])
                #print (source)
            if(row[1] in id_pers):
                target = row[1] + "_" + id_pers.get(row[1])
                print (source + "," + target)
                writer.write(source + "," + target + "\n")
                
# Personality for Colleagues Network
with open ("Personality_Colleagues.csv",'w') as writer:
    with open("Network_Colleagues_ids.csv",'r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers):
                source = row[0] + "_" + id_pers.get(row[0])
                #print (source)
            if(row[1] in id_pers):
                target = row[1] + "_" + id_pers.get(row[1])
                print (source + "," + target)
                writer.write(source + "," + target + "\n")

# Personality for Others Network
with open ("Personality_Others.csv",'w') as writer:
    with open("Network_Others_ids.csv",'r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print (row)
            if(row[0] in id_pers):
                source = row[0] + "_" + id_pers.get(row[0])
                #print (source)
            if(row[1] in id_pers):
                target = row[1] + "_" + id_pers.get(row[1])
                print (source + "," + target)
                writer.write(source + "," + target + "\n")

#Getting Relationship Count
with open ("Personality_Colleagues.csv",'r') as f:
    reader = csv.reader(f,delimiter = ',')
    O_O ,O_C ,O_E ,O_A ,O_N = 0, 0, 0, 0, 0 
    C_O ,C_C ,C_E ,C_A ,C_N = 0, 0, 0, 0, 0 
    E_O ,E_C ,E_E ,E_A ,E_N = 0, 0, 0, 0, 0 
    A_O ,A_C ,A_E ,A_A ,A_N = 0, 0, 0, 0, 0 
    N_O ,N_C ,N_E ,N_A ,N_N = 0, 0, 0, 0, 0 

    for row in reader:
            print(row)
            if ("Openness" in row[0]) and ("Openness" in row[1]):
                O_O = O_O + 1
            if ("Openness" in row[0]) and ("Conscientiousness" in row[1]):
                O_C = O_C + 1
            if ("Openness" in row[0]) and ("Extroversion" in row[1]):
                O_E = O_E + 1
            if ("Openness" in row[0]) and ("Agreeableness" in row[1]):
                O_A = O_A + 1
            if ("Openness" in row[0]) and ("Neuroticsm" in row[1]):
                O_N = O_N + 1
            if ("Conscientiousness" in row[0]) and ("Openness" in row[1]):
                C_O = C_O + 1
            if ("Conscientiousness" in row[0]) and ("Conscientiousness" in row[1]):
                C_C = C_C + 1
            if ("Conscientiousness" in row[0]) and ("Extroversion" in row[1]):
                C_E = C_E + 1
            if ("Conscientiousness" in row[0]) and ("Agreeableness" in row[1]):
                C_A = C_A + 1
            if ("Conscientiousness" in row[0]) and ("Neuroticsm" in row[1]):
                C_N = C_N + 1
            if ("Extroversion" in row[0]) and ("Openness" in row[1]):
                E_O = E_O + 1
            if ("Extroversion" in row[0]) and ("Conscientiousness" in row[1]):
                E_C = E_C + 1
            if ("Extroversion" in row[0]) and ("Extroversion" in row[1]):
                E_E = E_E + 1
            if ("Extroversion" in row[0]) and ("Agreeableness" in row[1]):
                E_A = E_A + 1
            if ("Extroversion" in row[0]) and ("Neuroticsm" in row[1]):
                E_N = E_N + 1
            if ("Agreeableness" in row[0]) and ("Openness" in row[1]):
                A_O = A_O + 1
            if ("Agreeableness" in row[0]) and ("Conscientiousness" in row[1]):
                A_C = A_C + 1
            if ("Agreeableness" in row[0]) and ("Extroversion" in row[1]):
                A_E = A_E + 1
            if ("Agreeableness" in row[0]) and ("Agreeableness" in row[1]):
                A_A = A_A + 1
            if ("Agreeableness" in row[0]) and ("Neuroticsm" in row[1]):
                A_N = A_N + 1
            if ("Neuroticsm" in row[0]) and ("Openness" in row[1]):
                N_O = N_O + 1
            if ("Neuroticsm" in row[0]) and ("Conscientiousness" in row[1]):
                N_C = N_C + 1
            if ("Neuroticsm" in row[0]) and ("Extroversion" in row[1]):
                N_E = N_E + 1
            if ("Neuroticsm" in row[0]) and ("Agreeableness" in row[1]):
                N_A = N_A + 1
            if ("Neuroticsm" in row[0]) and ("Neuroticsm" in row[1]):
                N_N = N_N + 1
with open ("Followers_Scores_Colleagues.csv",'w') as writer:
    writer.write("\t O \t C \t E \t A \t N \n")
    writer.write("O"+str(O_O)+"\t"+str(O_C)+"\t"+str(O_E)+"\t"+str(O_A)+"\t"+str(O_N)+"\n")
    writer.write("C"+str(C_O)+"\t"+str(C_C)+"\t"+str(C_E)+"\t"+str(C_A)+"\t"+str(C_N)+"\n")
    writer.write("E"+str(E_O)+"\t"+str(E_C)+"\t"+str(E_E)+"\t"+str(E_A)+"\t"+str(E_N)+"\n")
    writer.write("A"+str(A_O)+"\t"+str(A_C)+"\t"+str(A_E)+"\t"+str(A_A)+"\t"+str(A_N)+"\n")
    writer.write("N"+str(N_O)+"\t"+str(N_C)+"\t"+str(N_E)+"\t"+str(N_A)+"\t"+str(N_N)+"\n")
