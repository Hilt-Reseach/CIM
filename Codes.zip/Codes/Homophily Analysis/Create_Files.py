# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 16:54:51 2017

@author: Lenovo
"""

import os as os
import csv
from fnmatch import fnmatch
import pandas as pd
from sklearn.preprocessing import scale
import numpy as np
import operator
import json

#Read the directory and subdirectory
directory = "F:\\Categorized Network\\Network\\Followers\\Uname"
pattern = "*_status.txt"
for path, subdirs, files in os.walk(directory):
    for name in files:
        if fnmatch(name, pattern):
            print (os.path.join(name))
            with open (os.path.join(path,name),'r') as f:
                reader = csv.reader(f,delimiter = ',')
                for row in reader:
                    print (row)
            print ("Closing "+os.path.join(name))
            f.close()
            
#Read the scores file:
with open ('neurotic_scores.csv','w') as writer:
    with open ('test_scores_neurotic.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print(row[0])
            writer.write(row[2] + "\n")

#importing the dataset
dataset = pd.read_csv('personality_scores.csv')
dataset.columns = ['Openness','Conscientiousness','Extroversion','Agreeableness','Neuroticsm']
dataset.head()

#Scaling
X_Scale = scale(dataset[['Openness','Conscientiousness','Extroversion','Agreeableness','Neuroticsm']])
print (X_Scale)
#with open ('Scaled_Personality.csv','w') as sp:
np.savetxt('Scaled_Personality.csv',X_Scale,delimiter = ',',fmt='%1.4e')

#Zscore Normalization
with open ('scaled_personality_final.csv','w+') as writer:
    with open ('scaled_personality.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            zscore_list = []
            row = [float(i) for i in row]
            print(row)
            minimum = min(row)
            maximum = max(row)
            for each in row:
                zscore = (each - minimum)/(maximum - minimum)
                #print(zscore)
                zscore_list.append(zscore)
            print (zscore_list)
            index, value = max(enumerate(zscore_list), key=operator.itemgetter(1))
            writer.write(json.dumps(zscore_list)+str(index)+"\n")
            print(index)
            zscore_list.clear()

#Assigning the personalities
with open ('personalities.csv','w') as writer:
    with open ('scaled_personality_final.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            #print(type(row[5]))
            if(row[5] == "0"):
                row[5] = row[5].replace("0","Openness")
                print(row[5])
                writer.write(row[0]+","+row[1]+","+row[2]+","+row[3]+","+row[4]+","+row[5]+"\n")
            if(row[5] == "1"):
                row[5] = row[5].replace("1","Conscientiousness")
                print(row[5])
                writer.write(row[0]+","+row[1]+","+row[2]+","+row[3]+","+row[4]+","+row[5]+"\n")
            if(row[5] == "2"):
                row[5] = row[5].replace("2","Extroversion")
                print(row[5])
                writer.write(row[0]+","+row[1]+","+row[2]+","+row[3]+","+row[4]+","+row[5]+"\n")
            if(row[5] == "3"):
                row[5] = row[5].replace("3","Agreeableness")
                print(row[5])
                writer.write(row[0]+","+row[1]+","+row[2]+","+row[3]+","+row[4]+","+row[5]+"\n")
            if(row[5] == "4"):
                row[5] = row[5].replace("4","Neuroticsm")
                print(row[5])
                writer.write(row[0]+","+row[1]+","+row[2]+","+row[3]+","+row[4]+","+row[5]+"\n")
                

#Getting user list
                
user = []
with open ('prediction_ids_agreeable.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        print(row[0])
        if row[0] not in user:
            user.append(row[0])
    print(len(user))
    
with open ('unique_user_list.csv','w') as writer:
    for userid in user:
        writer.write(userid+"\n")

#Getting id,personality file
with open ('id_pers.csv','w') as writer:
    with open ('user_personality.csv','r') as f:
        reader = csv.reader(f,delimiter = ',')
        for row in reader:
            print(row[0]+","+row[6])
            writer.write(row[0]+","+row[6]+"\n")
            
with open ('user_personality.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        print()