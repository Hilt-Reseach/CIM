import csv
import numpy as np
from sklearn.preprocessing import normalize
from scipy import stats


def mean(numbers):
	return float(sum(numbers)) / max(len(numbers), 1)
'''
#Creating the Personality_Scores file
with open('Personality_scores_5.csv','w') as w:
	with open('Neurotic_scores.csv', 'rb') as f:
		reader = csv.reader(f, delimiter=',')
		for row in reader:
			print row[2]
			w.write (row[2]+"\n")

zscore = []
#Reading the scores file:
with open('Personality_Scores.csv','rb') as f:
	reader = csv.reader(f,delimiter = ',')
	for row in reader:
		row = [float(i) for i in row]
		a = np.array(row)
		print(row)
		M = reduce(lambda x, y: x + y, row) / float(len(row))
		print (M)
		S = np.std(a)
		maximum = max(row)
		minimum = min(row)
		print (S)
		print(maximum)
		print(minimum)
		for each in row:
			Z = (each-minimum)/(maximum-minimum)
			print(Z)
			#zscore.append(Z)
	#print(zscore)
		#a = a.reshape(1,-1)
		#print(stats.zscore(a))
		#Normalized = normalize(a, norm='l2', axis=1)
		#M = sum(row)/len(row) 
		#S = np.std(a)
		#print (a)
		#print ("Mean = "+M)
		#print ("SD = "+S)
'''

import pandas as pd
dataset = pd.read_csv('Personality_Scores.csv')
print(dataset)