import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import au.com.bytecode.opencsv.CSVReader;

public class Extract_Twitter_Data {
	
		
	public void read_directory(File directoryName){
	
		String filename;
		String followers;
		String followings;
		String status;
		String userid;
		String file_path = null;
		
		File[] files = directoryName.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				read_directory(file);
			} else {
				GetFollowers follower = new GetFollowers();
				GetFollowings following = new GetFollowings();
				GetStatus stat = new GetStatus();
				filename = file.getName().toLowerCase();
				try {
					file_path = file.getCanonicalPath().replaceAll(file.getName(), "");
					System.out.println("path"+ file_path);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.out.println("Problem with File Path");
				}
				//System.out.println("     file:" + filename);
				userid = filename.replaceAll("[a-z]", "");
				userid = userid.replaceAll("_.", "");
				//System.out.println(userid);
				followers = userid+"_followers.txt";
				followings = userid+"_followings.txt";
				status = userid+"_status.txt";		
				if(filename.contains(followers)){
					if (filename.contains(followings)) {
						
					}
					else{
						try {
							//follower.get_Followers(file_path, followings);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
	
	public void read_files(File directoryName){
		
		String[] line = null;
		
		String user_file = "F:\\Categorized Network\\Twitter_Dataset\\Followers_Files\\One_hop_followers.txt";
		System.out.println("Reading One Hop Followers File ..........................");
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader(user_file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found while reading One hop Followers File");
		}
		
		try {
			while ((line = reader.readNext()) != null) {
				String dir = directoryName+"\\"+line[0]+"\\";
				check_files(dir,line[0]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IOException on read_files");
		}
	}
	
	public void check_files(String directory,String uname){
		String dir = directory;
		String username = uname;
		File folder = new File(dir);
		File[] listOfFiles = folder.listFiles();
		System.out.println("Inside "+dir);
		for (File file : listOfFiles){
			if ((file.isDirectory() == false) && (file.getAbsolutePath().endsWith(".txt"))) {
				process_files(file.getName(),dir,username);
			}
        }
	}
	
	public void process_files(String filename,String file_path,String uname){
		String file = filename;
		String path = file_path;
		GetFollowers followers = new GetFollowers();
		GetFollowings followings = new GetFollowings();
		GetStatus status = new GetStatus();
		if (filename.contains("_followers.txt")){
			System.out.println("Followers file is present");
		}
		else{
			System.out.println("Followers file is not present");
			System.out.println("Extracting Followers File .....................");
			try {
				followers.get_Followers(path, uname);
				TimeUnit.MINUTES.sleep(1);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("FileNotFound Exception in process files method while extracting followers");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception in process files method while extracting followers");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("General Exception in process files method while extracting followers");
			}
		}
		if (filename.contains("_followings.txt")){
			System.out.println("Followings file is present");
		}
		else{
			System.out.println("Followings file is not present");
			System.out.println("Extracting Followings File .....................");
			try {
				followings.get_followings(path, uname);
				TimeUnit.MINUTES.sleep(1);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("FileNotFound Exception in process files method while extracting followings");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception in process files method while extracting followings");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("General Exception in process files method while extracting followings");
			}
		}
		if (filename.contains("_status.txt")){
			System.out.println("Status file is present");
		}
		else{
			System.out.println("Status file is not present");
			System.out.println("Extracting Status File .....................");
			try {
				status.get_status(path, uname);
				TimeUnit.MINUTES.sleep(1);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("FileNotFound Exception in process files method while extracting status");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception in process files method while extracting status");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("General Exception in process files method while extracting status");
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File directoryName = new File("F:\\Categorized Network\\Twitter_Dataset\\Followers_Complete\\");
		Extract_Twitter_Data etd = new Extract_Twitter_Data();
		//etd.read_directory(directoryName);
		etd.read_files(directoryName);
	}

}
