import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import twitter4j.PagableResponseList;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

import au.com.bytecode.opencsv.CSVReader;

public class TwitterDataCrawler {
	
	static int count = 0;

	File files_uname; 
	File files_followers;
	File files_followings;
	File files_status;
    File files_friends;
    File files_relatives;
    File files_colleagues;
    File files_friends_followers;
    File files_friends_followings;
    File files_friends_status;
    File files_relatives_followers;
    File files_relatives_followings;
    File files_relatives_status;
    File files_colleagues_followers;
    File files_colleagues_followings;
    File files_colleagues_status;
    
    String username;
    String followers;
    String followings;
    String friends;
    String relatives;
    String colleagues;
    String friends_followers;
    String friends_followings;
    String friends_status;
    String relatives_followers;
    String relatives_followings;
    String relatives_status;
    String colleagues_followers;
    String colleagues_followings;
    String colleagues_status;
    
	public void create_directory(String uname){
		
		files_uname = new File("F:\\CrawledTwitterData\\Uname\\"+uname); 
		files_followers = new File(files_uname+"\\Followers");
		files_followings = new File(files_uname+"\\Followings");
		files_status = new File(files_uname+"\\Status");
        files_friends = new File(files_uname+"\\Friends");
        files_friends_followers = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Friends\\Followers");
        files_friends_followings = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Friends\\Followings");
        files_friends_status = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Friends\\Status");
        files_relatives = new File(files_uname+"\\Relatives");
        files_relatives_followers = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Relatives\\Followers");
        files_relatives_followings = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Relatives\\Followings");
        files_relatives_status = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Relatives\\Status");
        files_colleagues = new File(files_uname+"\\Colleagues");
        files_colleagues_followers = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Colleagues\\Followers");
        files_colleagues_followings = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Colleagues\\Followings");
        files_colleagues_status = new File("F:\\CrawledTwitterData\\Uname\\"+uname+"\\Colleagues\\Status");
        
        username = files_uname.toString();
        followers = files_followers.toString();
        followings = files_followings.toString();
        friends = files_friends.toString();
        relatives = files_relatives.toString();
        colleagues = files_colleagues.toString();
        friends_followers = files_friends_followers.toString();
        friends_followings = files_friends_followings.toString();
        friends_status = files_friends_status.toString();
        relatives_followers = files_relatives_followers.toString();
        relatives_followings = files_relatives_followings.toString();
        relatives_status = files_relatives_status.toString();
        colleagues_followers = files_colleagues_followers.toString();
        colleagues_followings = files_colleagues_followings.toString();
        colleagues_status = files_colleagues_status.toString();
        
		if (!files_uname.exists()) {
            if (files_uname.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
		
        if (!files_followers.exists()) {
            if (files_followers.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_followings.exists()) {
            if (files_followings.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_status.exists()) {
            if (files_status.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_friends.exists()) {
            if (files_friends.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_relatives.exists()) {
            if (files_relatives.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_colleagues.exists()) {
            if (files_colleagues.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_friends_followers.exists()) {
            if (files_friends_followers.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_friends_followings.exists()) {
            if (files_friends_followings.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_friends_status.exists()) {
            if (files_friends_status.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_relatives_followers.exists()) {
            if (files_relatives_followers.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_relatives_followings.exists()) {
            if (files_relatives_followings.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_relatives_status.exists()) {
            if (files_relatives_status.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_colleagues_followers.exists()) {
            if (files_colleagues_followers.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_colleagues_followings.exists()) {
            if (files_colleagues_followings.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
        
        if (!files_colleagues_status.exists()) {
            if (files_colleagues_status.mkdirs()) {
                System.out.println("Multiple directories are created!");
            } else {
                System.out.println("Failed to create multiple directories!");
            }
        }
	}
	
	public void read_file(String path) throws Exception{

		CSVReader reader = new CSVReader(new FileReader(path));
		
		String[] line;
		String[] friend;
		String[] relative;
		String[] colleague;
		String[] other;
		int line_num = 1;
		
		
		
		while ((line = reader.readNext()) != null) {
			System.out.println(line_num);
			line_num++;
			System.out.println("uname :");
			line[0] = line[0].trim();
			create_directory(line[0]);
			split_names(username,line[0]);
			System.out.println("friends :");
			//line[1] = line[1].trim();
			//split_names(friends, line[1]);
	        //System.out.println("friends :");
	        friend = line[1].split(",");
	        for(int i = 0; i < friend.length; i++){
			split_names(friends,friend[i]);
	       }
			System.out.println("relatives :");
			//split_names(line[2]);
			relative = line[2].split(",");
	        for(int i = 0; i < relative.length; i++){
			split_names(relatives,relative[i]);
	       }
			System.out.println("colleagues :");
			//split_names(line[3]);
			colleague = line[3].split(",");
	        for(int i = 0; i < colleague.length; i++){
			split_names(colleagues,colleague[i]);
	       }
			//System.out.println("others :");
			//split_names(line[4]);
			//other = line[4].split(",");
	        //for(int i = 0; i < other.length; i++){
			//split_names(others,other[i]);
	       //}
		}	
		
		reader.close();
		
	}	
	
	public static void file_append(String path,String txt) 
    {
   	 try
   	 {
   	        
            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(path, true), "UTF-8");
            BufferedWriter fbw = new BufferedWriter(writer);
            fbw.write(txt);
            fbw.newLine();
            fbw.close();
        }
   	 catch (Exception e) 
        {
            System.out.println("Error: " + e.getMessage());
        }
    }	
	public void split_names(String file_path,String names) throws FileNotFoundException, IOException, Exception{
		if(names.equals("NULL")){
			System.out.println("Value is Null!!!");
		}
		else
		{
		System.out.println(names);
		String name[] = names.split(",");
		for(int i = 0; i < name.length; i++){
			name[i] = name[i].trim();
			System.out.println("name "+count+" = "+name[i]);
			count++;
			GetFollowers followers = new GetFollowers();
			followers.get_Followers(file_path,name[i]);
			GetFollowings followings = new GetFollowings();
			followings.get_followings(file_path,name[i]);
			GetStatus status = new GetStatus();
			status.get_status(file_path,name[i]);
			}
		}
	}
	
	public static void write_to_file(String path, String data){
		try
   	 {
   		 	String split_data[] = data.split(",");
            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(path, true), "UTF-8");
            BufferedWriter fbw = new BufferedWriter(writer);
            for(int i = 0; i < split_data.length; i++){
            	fbw.write(split_data[i]);
            	fbw.newLine();
            }
            fbw.close();
        }
   	 catch (Exception e) 
        {
            System.out.println("Error: " + e.getMessage());
        }
	}
	
	public static void write_to_file_status(String path, String data){
		try
   	 {
   		 	String split_data[] = data.split("~");
            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(path, true), "UTF-8");
            BufferedWriter fbw = new BufferedWriter(writer);
            for(int i = 0; i < split_data.length; i++){
            	fbw.write(split_data[i]);
            	fbw.newLine();
            }
            fbw.close();
        }
   	 catch (Exception e) 
        {
            System.out.println("Error: " + e.getMessage());
        }
	}
	 
	public static void main(String[] args) throws Exception {
		String path = "F://CrawledTwitterData//Followers_test.csv";
		//String path = "F://twitter.csv";
		TwitterDataCrawler tdc = new TwitterDataCrawler();
		tdc.read_file(path);
	}

}
