import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import twitter4j.PagableResponseList;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class GetFollowings {

	int count = 0;
	String userName = null;
	String path_followings;
	
		public static String consumerKey1="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret1="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken1="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret1="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey2="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret2="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken2="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret2="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey3="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret3="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken3="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret3="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey4="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret4="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken4="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret4="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey5="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret5="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken5="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret5="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey6="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret6="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken6="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret6="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey7="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret7="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken7="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret7="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	.....
	.....
	.....
	public static String consumerKey139="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret139="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken139="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret139="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey140="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret140="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken140="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret140="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey141="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret141="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken141="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret141="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

	public static String consumerKey142="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String consumerSecret142="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterToken142="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	public static String twitterSecret142="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	
	int Low = 0;
	int High = 142;
	Random r = new Random();
	int loop_count  = r.nextInt(High-Low) + Low;
	int l = r.nextInt(High-Low) + Low;
	
	 public ArrayList<String> followings = new ArrayList();
	 public ArrayList<String> followingsTname = new ArrayList();
	
	    
    public void get_followings(String file_path,String uname) throws FileNotFoundException, IOException, Exception {
//        FileInputStream fstream = new FileInputStream("/home/pykl/Desktop/uniquelist.txt");
//        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
//        ArrayList userName = new ArrayList();
//        //ArrayList userID = new ArrayList();
      String strLine=uname;
        int i = 0;
        int Low_local = 0	;
		int High_local = 142;
//        //Read File Line By Line
        int l = 0;
        int p =  r.nextInt(High_local-Low_local) + Low_local;
//        while ((strLine = br.readLine()) != null) {
//            //System.out.println(strLine);
//            //userName.add(strLine);
            i = i + 1;
            l=p+1;
//            System.out.println("lvalue"+l);
            p= dataextraction(file_path,strLine,i,l);
       // }

    }
    
    public int dataextraction(String file_path,String usrName, int j, int lstatus) throws InterruptedException, Exception {

        /**
         * **
         */
        ConfigurationBuilder cb1= new ConfigurationBuilder();
cb1.setOAuthConsumerKey(consumerKey1);
cb1.setOAuthConsumerSecret(consumerSecret1);
cb1.setOAuthAccessToken(twitterToken1);
cb1.setOAuthAccessTokenSecret(twitterSecret1);

ConfigurationBuilder cb2= new ConfigurationBuilder();
cb2.setOAuthConsumerKey(consumerKey2);
cb2.setOAuthConsumerSecret(consumerSecret2);
cb2.setOAuthAccessToken(twitterToken2);
cb2.setOAuthAccessTokenSecret(twitterSecret2);

ConfigurationBuilder cb3= new ConfigurationBuilder();
cb3.setOAuthConsumerKey(consumerKey3);
cb3.setOAuthConsumerSecret(consumerSecret3);
cb3.setOAuthAccessToken(twitterToken3);
cb3.setOAuthAccessTokenSecret(twitterSecret3);

ConfigurationBuilder cb4= new ConfigurationBuilder();
cb4.setOAuthConsumerKey(consumerKey4);
cb4.setOAuthConsumerSecret(consumerSecret4);
cb4.setOAuthAccessToken(twitterToken4);
cb4.setOAuthAccessTokenSecret(twitterSecret4);

ConfigurationBuilder cb5= new ConfigurationBuilder();
cb5.setOAuthConsumerKey(consumerKey5);
cb5.setOAuthConsumerSecret(consumerSecret5);
cb5.setOAuthAccessToken(twitterToken5);
cb5.setOAuthAccessTokenSecret(twitterSecret5);

ConfigurationBuilder cb6= new ConfigurationBuilder();
cb6.setOAuthConsumerKey(consumerKey6);
cb6.setOAuthConsumerSecret(consumerSecret6);
cb6.setOAuthAccessToken(twitterToken6);
cb6.setOAuthAccessTokenSecret(twitterSecret6);

ConfigurationBuilder cb7= new ConfigurationBuilder();
cb7.setOAuthConsumerKey(consumerKey7);
cb7.setOAuthConsumerSecret(consumerSecret7);
cb7.setOAuthAccessToken(twitterToken7);
cb7.setOAuthAccessTokenSecret(twitterSecret7);

ConfigurationBuilder cb8= new ConfigurationBuilder();
cb8.setOAuthConsumerKey(consumerKey8);
cb8.setOAuthConsumerSecret(consumerSecret8);
cb8.setOAuthAccessToken(twitterToken8);
cb8.setOAuthAccessTokenSecret(twitterSecret8);

ConfigurationBuilder cb9= new ConfigurationBuilder();
cb9.setOAuthConsumerKey(consumerKey9);
cb9.setOAuthConsumerSecret(consumerSecret9);
cb9.setOAuthAccessToken(twitterToken9);
cb9.setOAuthAccessTokenSecret(twitterSecret9);

ConfigurationBuilder cb10= new ConfigurationBuilder();
cb10.setOAuthConsumerKey(consumerKey10);
cb10.setOAuthConsumerSecret(consumerSecret10);
cb10.setOAuthAccessToken(twitterToken10);
cb10.setOAuthAccessTokenSecret(twitterSecret10);

ConfigurationBuilder cb11= new ConfigurationBuilder();
cb11.setOAuthConsumerKey(consumerKey11);
cb11.setOAuthConsumerSecret(consumerSecret11);
cb11.setOAuthAccessToken(twitterToken11);
cb11.setOAuthAccessTokenSecret(twitterSecret11);

ConfigurationBuilder cb12= new ConfigurationBuilder();
cb12.setOAuthConsumerKey(consumerKey12);
cb12.setOAuthConsumerSecret(consumerSecret12);
cb12.setOAuthAccessToken(twitterToken12);
cb12.setOAuthAccessTokenSecret(twitterSecret12);

ConfigurationBuilder cb13= new ConfigurationBuilder();
cb13.setOAuthConsumerKey(consumerKey13);
cb13.setOAuthConsumerSecret(consumerSecret13);
cb13.setOAuthAccessToken(twitterToken13);
cb13.setOAuthAccessTokenSecret(twitterSecret13);

ConfigurationBuilder cb14= new ConfigurationBuilder();
cb14.setOAuthConsumerKey(consumerKey14);
cb14.setOAuthConsumerSecret(consumerSecret14);
cb14.setOAuthAccessToken(twitterToken14);
cb14.setOAuthAccessTokenSecret(twitterSecret14);

ConfigurationBuilder cb15= new ConfigurationBuilder();
cb15.setOAuthConsumerKey(consumerKey15);
cb15.setOAuthConsumerSecret(consumerSecret15);
cb15.setOAuthAccessToken(twitterToken15);
cb15.setOAuthAccessTokenSecret(twitterSecret15);

ConfigurationBuilder cb16= new ConfigurationBuilder();
cb16.setOAuthConsumerKey(consumerKey16);
cb16.setOAuthConsumerSecret(consumerSecret16);
cb16.setOAuthAccessToken(twitterToken16);
cb16.setOAuthAccessTokenSecret(twitterSecret16);

ConfigurationBuilder cb17= new ConfigurationBuilder();
cb17.setOAuthConsumerKey(consumerKey17);
cb17.setOAuthConsumerSecret(consumerSecret17);
cb17.setOAuthAccessToken(twitterToken17);
cb17.setOAuthAccessTokenSecret(twitterSecret17);

ConfigurationBuilder cb18= new ConfigurationBuilder();
cb18.setOAuthConsumerKey(consumerKey18);
cb18.setOAuthConsumerSecret(consumerSecret18);
cb18.setOAuthAccessToken(twitterToken18);
cb18.setOAuthAccessTokenSecret(twitterSecret18);

ConfigurationBuilder cb19= new ConfigurationBuilder();
cb19.setOAuthConsumerKey(consumerKey19);
cb19.setOAuthConsumerSecret(consumerSecret19);
cb19.setOAuthAccessToken(twitterToken19);
cb19.setOAuthAccessTokenSecret(twitterSecret19);

ConfigurationBuilder cb20= new ConfigurationBuilder();
cb20.setOAuthConsumerKey(consumerKey20);
cb20.setOAuthConsumerSecret(consumerSecret20);
cb20.setOAuthAccessToken(twitterToken20);
cb20.setOAuthAccessTokenSecret(twitterSecret20);

ConfigurationBuilder cb21= new ConfigurationBuilder();
cb21.setOAuthConsumerKey(consumerKey21);
cb21.setOAuthConsumerSecret(consumerSecret21);
cb21.setOAuthAccessToken(twitterToken21);
cb21.setOAuthAccessTokenSecret(twitterSecret21);

ConfigurationBuilder cb22= new ConfigurationBuilder();
cb22.setOAuthConsumerKey(consumerKey22);
cb22.setOAuthConsumerSecret(consumerSecret22);
cb22.setOAuthAccessToken(twitterToken22);
cb22.setOAuthAccessTokenSecret(twitterSecret22);

ConfigurationBuilder cb23= new ConfigurationBuilder();
cb23.setOAuthConsumerKey(consumerKey23);
cb23.setOAuthConsumerSecret(consumerSecret23);
cb23.setOAuthAccessToken(twitterToken23);
cb23.setOAuthAccessTokenSecret(twitterSecret23);

ConfigurationBuilder cb24= new ConfigurationBuilder();
cb24.setOAuthConsumerKey(consumerKey24);
cb24.setOAuthConsumerSecret(consumerSecret24);
cb24.setOAuthAccessToken(twitterToken24);
cb24.setOAuthAccessTokenSecret(twitterSecret24);

ConfigurationBuilder cb25= new ConfigurationBuilder();
cb25.setOAuthConsumerKey(consumerKey25);
cb25.setOAuthConsumerSecret(consumerSecret25);
cb25.setOAuthAccessToken(twitterToken25);
cb25.setOAuthAccessTokenSecret(twitterSecret25);

ConfigurationBuilder cb26= new ConfigurationBuilder();
cb26.setOAuthConsumerKey(consumerKey26);
cb26.setOAuthConsumerSecret(consumerSecret26);
cb26.setOAuthAccessToken(twitterToken26);
cb26.setOAuthAccessTokenSecret(twitterSecret26);

ConfigurationBuilder cb27= new ConfigurationBuilder();
cb27.setOAuthConsumerKey(consumerKey27);
cb27.setOAuthConsumerSecret(consumerSecret27);
cb27.setOAuthAccessToken(twitterToken27);
cb27.setOAuthAccessTokenSecret(twitterSecret27);

ConfigurationBuilder cb28= new ConfigurationBuilder();
cb28.setOAuthConsumerKey(consumerKey28);
cb28.setOAuthConsumerSecret(consumerSecret28);
cb28.setOAuthAccessToken(twitterToken28);
cb28.setOAuthAccessTokenSecret(twitterSecret28);

ConfigurationBuilder cb29= new ConfigurationBuilder();
cb29.setOAuthConsumerKey(consumerKey29);
cb29.setOAuthConsumerSecret(consumerSecret29);
cb29.setOAuthAccessToken(twitterToken29);
cb29.setOAuthAccessTokenSecret(twitterSecret29);

ConfigurationBuilder cb30= new ConfigurationBuilder();
cb30.setOAuthConsumerKey(consumerKey30);
cb30.setOAuthConsumerSecret(consumerSecret30);
cb30.setOAuthAccessToken(twitterToken30);
cb30.setOAuthAccessTokenSecret(twitterSecret30);

ConfigurationBuilder cb31= new ConfigurationBuilder();
cb31.setOAuthConsumerKey(consumerKey31);
cb31.setOAuthConsumerSecret(consumerSecret31);
cb31.setOAuthAccessToken(twitterToken31);
cb31.setOAuthAccessTokenSecret(twitterSecret31);

ConfigurationBuilder cb32= new ConfigurationBuilder();
cb32.setOAuthConsumerKey(consumerKey32);
cb32.setOAuthConsumerSecret(consumerSecret32);
cb32.setOAuthAccessToken(twitterToken32);
cb32.setOAuthAccessTokenSecret(twitterSecret32);

ConfigurationBuilder cb33= new ConfigurationBuilder();
cb33.setOAuthConsumerKey(consumerKey33);
cb33.setOAuthConsumerSecret(consumerSecret33);
cb33.setOAuthAccessToken(twitterToken33);
cb33.setOAuthAccessTokenSecret(twitterSecret33);

ConfigurationBuilder cb34= new ConfigurationBuilder();
cb34.setOAuthConsumerKey(consumerKey34);
cb34.setOAuthConsumerSecret(consumerSecret34);
cb34.setOAuthAccessToken(twitterToken34);
cb34.setOAuthAccessTokenSecret(twitterSecret34);

ConfigurationBuilder cb35= new ConfigurationBuilder();
cb35.setOAuthConsumerKey(consumerKey35);
cb35.setOAuthConsumerSecret(consumerSecret35);
cb35.setOAuthAccessToken(twitterToken35);
cb35.setOAuthAccessTokenSecret(twitterSecret35);

ConfigurationBuilder cb36= new ConfigurationBuilder();
cb36.setOAuthConsumerKey(consumerKey36);
cb36.setOAuthConsumerSecret(consumerSecret36);
cb36.setOAuthAccessToken(twitterToken36);
cb36.setOAuthAccessTokenSecret(twitterSecret36);

ConfigurationBuilder cb37= new ConfigurationBuilder();
cb37.setOAuthConsumerKey(consumerKey37);
cb37.setOAuthConsumerSecret(consumerSecret37);
cb37.setOAuthAccessToken(twitterToken37);
cb37.setOAuthAccessTokenSecret(twitterSecret37);

ConfigurationBuilder cb38= new ConfigurationBuilder();
cb38.setOAuthConsumerKey(consumerKey38);
cb38.setOAuthConsumerSecret(consumerSecret38);
cb38.setOAuthAccessToken(twitterToken38);
cb38.setOAuthAccessTokenSecret(twitterSecret38);

ConfigurationBuilder cb39= new ConfigurationBuilder();
cb39.setOAuthConsumerKey(consumerKey39);
cb39.setOAuthConsumerSecret(consumerSecret39);
cb39.setOAuthAccessToken(twitterToken39);
cb39.setOAuthAccessTokenSecret(twitterSecret39);

ConfigurationBuilder cb40= new ConfigurationBuilder();
cb40.setOAuthConsumerKey(consumerKey40);
cb40.setOAuthConsumerSecret(consumerSecret40);
cb40.setOAuthAccessToken(twitterToken40);
cb40.setOAuthAccessTokenSecret(twitterSecret40);

ConfigurationBuilder cb41= new ConfigurationBuilder();
cb41.setOAuthConsumerKey(consumerKey41);
cb41.setOAuthConsumerSecret(consumerSecret41);
cb41.setOAuthAccessToken(twitterToken41);
cb41.setOAuthAccessTokenSecret(twitterSecret41);

ConfigurationBuilder cb42= new ConfigurationBuilder();
cb42.setOAuthConsumerKey(consumerKey42);
cb42.setOAuthConsumerSecret(consumerSecret42);
cb42.setOAuthAccessToken(twitterToken42);
cb42.setOAuthAccessTokenSecret(twitterSecret42);

ConfigurationBuilder cb43= new ConfigurationBuilder();
cb43.setOAuthConsumerKey(consumerKey43);
cb43.setOAuthConsumerSecret(consumerSecret43);
cb43.setOAuthAccessToken(twitterToken43);
cb43.setOAuthAccessTokenSecret(twitterSecret43);

ConfigurationBuilder cb44= new ConfigurationBuilder();
cb44.setOAuthConsumerKey(consumerKey44);
cb44.setOAuthConsumerSecret(consumerSecret44);
cb44.setOAuthAccessToken(twitterToken44);
cb44.setOAuthAccessTokenSecret(twitterSecret44);

ConfigurationBuilder cb45= new ConfigurationBuilder();
cb45.setOAuthConsumerKey(consumerKey45);
cb45.setOAuthConsumerSecret(consumerSecret45);
cb45.setOAuthAccessToken(twitterToken45);
cb45.setOAuthAccessTokenSecret(twitterSecret45);

ConfigurationBuilder cb46= new ConfigurationBuilder();
cb46.setOAuthConsumerKey(consumerKey46);
cb46.setOAuthConsumerSecret(consumerSecret46);
cb46.setOAuthAccessToken(twitterToken46);
cb46.setOAuthAccessTokenSecret(twitterSecret46);

ConfigurationBuilder cb47= new ConfigurationBuilder();
cb47.setOAuthConsumerKey(consumerKey47);
cb47.setOAuthConsumerSecret(consumerSecret47);
cb47.setOAuthAccessToken(twitterToken47);
cb47.setOAuthAccessTokenSecret(twitterSecret47);

ConfigurationBuilder cb48= new ConfigurationBuilder();
cb48.setOAuthConsumerKey(consumerKey48);
cb48.setOAuthConsumerSecret(consumerSecret48);
cb48.setOAuthAccessToken(twitterToken48);
cb48.setOAuthAccessTokenSecret(twitterSecret48);

ConfigurationBuilder cb49= new ConfigurationBuilder();
cb49.setOAuthConsumerKey(consumerKey49);
cb49.setOAuthConsumerSecret(consumerSecret49);
cb49.setOAuthAccessToken(twitterToken49);
cb49.setOAuthAccessTokenSecret(twitterSecret49);

ConfigurationBuilder cb50= new ConfigurationBuilder();
cb50.setOAuthConsumerKey(consumerKey50);
cb50.setOAuthConsumerSecret(consumerSecret50);
cb50.setOAuthAccessToken(twitterToken50);
cb50.setOAuthAccessTokenSecret(twitterSecret50);

ConfigurationBuilder cb51= new ConfigurationBuilder();
cb51.setOAuthConsumerKey(consumerKey51);
cb51.setOAuthConsumerSecret(consumerSecret51);
cb51.setOAuthAccessToken(twitterToken51);
cb51.setOAuthAccessTokenSecret(twitterSecret51);

ConfigurationBuilder cb52= new ConfigurationBuilder();
cb52.setOAuthConsumerKey(consumerKey52);
cb52.setOAuthConsumerSecret(consumerSecret52);
cb52.setOAuthAccessToken(twitterToken52);
cb52.setOAuthAccessTokenSecret(twitterSecret52);

ConfigurationBuilder cb53= new ConfigurationBuilder();
cb53.setOAuthConsumerKey(consumerKey53);
cb53.setOAuthConsumerSecret(consumerSecret53);
cb53.setOAuthAccessToken(twitterToken53);
cb53.setOAuthAccessTokenSecret(twitterSecret53);

ConfigurationBuilder cb54= new ConfigurationBuilder();
cb54.setOAuthConsumerKey(consumerKey54);
cb54.setOAuthConsumerSecret(consumerSecret54);
cb54.setOAuthAccessToken(twitterToken54);
cb54.setOAuthAccessTokenSecret(twitterSecret54);

ConfigurationBuilder cb55= new ConfigurationBuilder();
cb55.setOAuthConsumerKey(consumerKey55);
cb55.setOAuthConsumerSecret(consumerSecret55);
cb55.setOAuthAccessToken(twitterToken55);
cb55.setOAuthAccessTokenSecret(twitterSecret55);

ConfigurationBuilder cb56= new ConfigurationBuilder();
cb56.setOAuthConsumerKey(consumerKey56);
cb56.setOAuthConsumerSecret(consumerSecret56);
cb56.setOAuthAccessToken(twitterToken56);
cb56.setOAuthAccessTokenSecret(twitterSecret56);

ConfigurationBuilder cb57= new ConfigurationBuilder();
cb57.setOAuthConsumerKey(consumerKey57);
cb57.setOAuthConsumerSecret(consumerSecret57);
cb57.setOAuthAccessToken(twitterToken57);
cb57.setOAuthAccessTokenSecret(twitterSecret57);

ConfigurationBuilder cb58= new ConfigurationBuilder();
cb58.setOAuthConsumerKey(consumerKey58);
cb58.setOAuthConsumerSecret(consumerSecret58);
cb58.setOAuthAccessToken(twitterToken58);
cb58.setOAuthAccessTokenSecret(twitterSecret58);

ConfigurationBuilder cb59= new ConfigurationBuilder();
cb59.setOAuthConsumerKey(consumerKey59);
cb59.setOAuthConsumerSecret(consumerSecret59);
cb59.setOAuthAccessToken(twitterToken59);
cb59.setOAuthAccessTokenSecret(twitterSecret59);

ConfigurationBuilder cb60= new ConfigurationBuilder();
cb60.setOAuthConsumerKey(consumerKey60);
cb60.setOAuthConsumerSecret(consumerSecret60);
cb60.setOAuthAccessToken(twitterToken60);
cb60.setOAuthAccessTokenSecret(twitterSecret60);

ConfigurationBuilder cb61= new ConfigurationBuilder();
cb61.setOAuthConsumerKey(consumerKey61);
cb61.setOAuthConsumerSecret(consumerSecret61);
cb61.setOAuthAccessToken(twitterToken61);
cb61.setOAuthAccessTokenSecret(twitterSecret61);

ConfigurationBuilder cb62= new ConfigurationBuilder();
cb62.setOAuthConsumerKey(consumerKey62);
cb62.setOAuthConsumerSecret(consumerSecret62);
cb62.setOAuthAccessToken(twitterToken62);
cb62.setOAuthAccessTokenSecret(twitterSecret62);

ConfigurationBuilder cb63= new ConfigurationBuilder();
cb63.setOAuthConsumerKey(consumerKey63);
cb63.setOAuthConsumerSecret(consumerSecret63);
cb63.setOAuthAccessToken(twitterToken63);
cb63.setOAuthAccessTokenSecret(twitterSecret63);

ConfigurationBuilder cb64= new ConfigurationBuilder();
cb64.setOAuthConsumerKey(consumerKey64);
cb64.setOAuthConsumerSecret(consumerSecret64);
cb64.setOAuthAccessToken(twitterToken64);
cb64.setOAuthAccessTokenSecret(twitterSecret64);

ConfigurationBuilder cb65= new ConfigurationBuilder();
cb65.setOAuthConsumerKey(consumerKey65);
cb65.setOAuthConsumerSecret(consumerSecret65);
cb65.setOAuthAccessToken(twitterToken65);
cb65.setOAuthAccessTokenSecret(twitterSecret65);

ConfigurationBuilder cb66= new ConfigurationBuilder();
cb66.setOAuthConsumerKey(consumerKey66);
cb66.setOAuthConsumerSecret(consumerSecret66);
cb66.setOAuthAccessToken(twitterToken66);
cb66.setOAuthAccessTokenSecret(twitterSecret66);

ConfigurationBuilder cb67= new ConfigurationBuilder();
cb67.setOAuthConsumerKey(consumerKey67);
cb67.setOAuthConsumerSecret(consumerSecret67);
cb67.setOAuthAccessToken(twitterToken67);
cb67.setOAuthAccessTokenSecret(twitterSecret67);

ConfigurationBuilder cb68= new ConfigurationBuilder();
cb68.setOAuthConsumerKey(consumerKey68);
cb68.setOAuthConsumerSecret(consumerSecret68);
cb68.setOAuthAccessToken(twitterToken68);
cb68.setOAuthAccessTokenSecret(twitterSecret68);

ConfigurationBuilder cb69= new ConfigurationBuilder();
cb69.setOAuthConsumerKey(consumerKey69);
cb69.setOAuthConsumerSecret(consumerSecret69);
cb69.setOAuthAccessToken(twitterToken69);
cb69.setOAuthAccessTokenSecret(twitterSecret69);

ConfigurationBuilder cb70= new ConfigurationBuilder();
cb70.setOAuthConsumerKey(consumerKey70);
cb70.setOAuthConsumerSecret(consumerSecret70);
cb70.setOAuthAccessToken(twitterToken70);
cb70.setOAuthAccessTokenSecret(twitterSecret70);

ConfigurationBuilder cb71= new ConfigurationBuilder();
cb71.setOAuthConsumerKey(consumerKey71);
cb71.setOAuthConsumerSecret(consumerSecret71);
cb71.setOAuthAccessToken(twitterToken71);
cb71.setOAuthAccessTokenSecret(twitterSecret71);

ConfigurationBuilder cb72= new ConfigurationBuilder();
cb72.setOAuthConsumerKey(consumerKey72);
cb72.setOAuthConsumerSecret(consumerSecret72);
cb72.setOAuthAccessToken(twitterToken72);
cb72.setOAuthAccessTokenSecret(twitterSecret72);

ConfigurationBuilder cb73= new ConfigurationBuilder();
cb73.setOAuthConsumerKey(consumerKey73);
cb73.setOAuthConsumerSecret(consumerSecret73);
cb73.setOAuthAccessToken(twitterToken73);
cb73.setOAuthAccessTokenSecret(twitterSecret73);

ConfigurationBuilder cb74= new ConfigurationBuilder();
cb74.setOAuthConsumerKey(consumerKey74);
cb74.setOAuthConsumerSecret(consumerSecret74);
cb74.setOAuthAccessToken(twitterToken74);
cb74.setOAuthAccessTokenSecret(twitterSecret74);

ConfigurationBuilder cb75= new ConfigurationBuilder();
cb75.setOAuthConsumerKey(consumerKey75);
cb75.setOAuthConsumerSecret(consumerSecret75);
cb75.setOAuthAccessToken(twitterToken75);
cb75.setOAuthAccessTokenSecret(twitterSecret75);

ConfigurationBuilder cb76= new ConfigurationBuilder();
cb76.setOAuthConsumerKey(consumerKey76);
cb76.setOAuthConsumerSecret(consumerSecret76);
cb76.setOAuthAccessToken(twitterToken76);
cb76.setOAuthAccessTokenSecret(twitterSecret76);

ConfigurationBuilder cb77= new ConfigurationBuilder();
cb77.setOAuthConsumerKey(consumerKey77);
cb77.setOAuthConsumerSecret(consumerSecret77);
cb77.setOAuthAccessToken(twitterToken77);
cb77.setOAuthAccessTokenSecret(twitterSecret77);

ConfigurationBuilder cb78= new ConfigurationBuilder();
cb78.setOAuthConsumerKey(consumerKey78);
cb78.setOAuthConsumerSecret(consumerSecret78);
cb78.setOAuthAccessToken(twitterToken78);
cb78.setOAuthAccessTokenSecret(twitterSecret78);

ConfigurationBuilder cb79= new ConfigurationBuilder();
cb79.setOAuthConsumerKey(consumerKey79);
cb79.setOAuthConsumerSecret(consumerSecret79);
cb79.setOAuthAccessToken(twitterToken79);
cb79.setOAuthAccessTokenSecret(twitterSecret79);

ConfigurationBuilder cb80= new ConfigurationBuilder();
cb80.setOAuthConsumerKey(consumerKey80);
cb80.setOAuthConsumerSecret(consumerSecret80);
cb80.setOAuthAccessToken(twitterToken80);
cb80.setOAuthAccessTokenSecret(twitterSecret80);

ConfigurationBuilder cb81= new ConfigurationBuilder();
cb81.setOAuthConsumerKey(consumerKey81);
cb81.setOAuthConsumerSecret(consumerSecret81);
cb81.setOAuthAccessToken(twitterToken81);
cb81.setOAuthAccessTokenSecret(twitterSecret81);

ConfigurationBuilder cb82= new ConfigurationBuilder();
cb82.setOAuthConsumerKey(consumerKey82);
cb82.setOAuthConsumerSecret(consumerSecret82);
cb82.setOAuthAccessToken(twitterToken82);
cb82.setOAuthAccessTokenSecret(twitterSecret82);

ConfigurationBuilder cb83= new ConfigurationBuilder();
cb83.setOAuthConsumerKey(consumerKey83);
cb83.setOAuthConsumerSecret(consumerSecret83);
cb83.setOAuthAccessToken(twitterToken83);
cb83.setOAuthAccessTokenSecret(twitterSecret83);

ConfigurationBuilder cb84= new ConfigurationBuilder();
cb84.setOAuthConsumerKey(consumerKey84);
cb84.setOAuthConsumerSecret(consumerSecret84);
cb84.setOAuthAccessToken(twitterToken84);
cb84.setOAuthAccessTokenSecret(twitterSecret84);

ConfigurationBuilder cb85= new ConfigurationBuilder();
cb85.setOAuthConsumerKey(consumerKey85);
cb85.setOAuthConsumerSecret(consumerSecret85);
cb85.setOAuthAccessToken(twitterToken85);
cb85.setOAuthAccessTokenSecret(twitterSecret85);

ConfigurationBuilder cb86= new ConfigurationBuilder();
cb86.setOAuthConsumerKey(consumerKey86);
cb86.setOAuthConsumerSecret(consumerSecret86);
cb86.setOAuthAccessToken(twitterToken86);
cb86.setOAuthAccessTokenSecret(twitterSecret86);

ConfigurationBuilder cb87= new ConfigurationBuilder();
cb87.setOAuthConsumerKey(consumerKey87);
cb87.setOAuthConsumerSecret(consumerSecret87);
cb87.setOAuthAccessToken(twitterToken87);
cb87.setOAuthAccessTokenSecret(twitterSecret87);

ConfigurationBuilder cb88= new ConfigurationBuilder();
cb88.setOAuthConsumerKey(consumerKey88);
cb88.setOAuthConsumerSecret(consumerSecret88);
cb88.setOAuthAccessToken(twitterToken88);
cb88.setOAuthAccessTokenSecret(twitterSecret88);

ConfigurationBuilder cb89= new ConfigurationBuilder();
cb89.setOAuthConsumerKey(consumerKey89);
cb89.setOAuthConsumerSecret(consumerSecret89);
cb89.setOAuthAccessToken(twitterToken89);
cb89.setOAuthAccessTokenSecret(twitterSecret89);

ConfigurationBuilder cb90= new ConfigurationBuilder();
cb90.setOAuthConsumerKey(consumerKey90);
cb90.setOAuthConsumerSecret(consumerSecret90);
cb90.setOAuthAccessToken(twitterToken90);
cb90.setOAuthAccessTokenSecret(twitterSecret90);

ConfigurationBuilder cb91= new ConfigurationBuilder();
cb91.setOAuthConsumerKey(consumerKey91);
cb91.setOAuthConsumerSecret(consumerSecret91);
cb91.setOAuthAccessToken(twitterToken91);
cb91.setOAuthAccessTokenSecret(twitterSecret91);

ConfigurationBuilder cb92= new ConfigurationBuilder();
cb92.setOAuthConsumerKey(consumerKey92);
cb92.setOAuthConsumerSecret(consumerSecret92);
cb92.setOAuthAccessToken(twitterToken92);
cb92.setOAuthAccessTokenSecret(twitterSecret92);

ConfigurationBuilder cb93= new ConfigurationBuilder();
cb93.setOAuthConsumerKey(consumerKey93);
cb93.setOAuthConsumerSecret(consumerSecret93);
cb93.setOAuthAccessToken(twitterToken93);
cb93.setOAuthAccessTokenSecret(twitterSecret93);

ConfigurationBuilder cb94= new ConfigurationBuilder();
cb94.setOAuthConsumerKey(consumerKey94);
cb94.setOAuthConsumerSecret(consumerSecret94);
cb94.setOAuthAccessToken(twitterToken94);
cb94.setOAuthAccessTokenSecret(twitterSecret94);

ConfigurationBuilder cb95= new ConfigurationBuilder();
cb95.setOAuthConsumerKey(consumerKey95);
cb95.setOAuthConsumerSecret(consumerSecret95);
cb95.setOAuthAccessToken(twitterToken95);
cb95.setOAuthAccessTokenSecret(twitterSecret95);

ConfigurationBuilder cb96= new ConfigurationBuilder();
cb96.setOAuthConsumerKey(consumerKey96);
cb96.setOAuthConsumerSecret(consumerSecret96);
cb96.setOAuthAccessToken(twitterToken96);
cb96.setOAuthAccessTokenSecret(twitterSecret96);

ConfigurationBuilder cb97= new ConfigurationBuilder();
cb97.setOAuthConsumerKey(consumerKey97);
cb97.setOAuthConsumerSecret(consumerSecret97);
cb97.setOAuthAccessToken(twitterToken97);
cb97.setOAuthAccessTokenSecret(twitterSecret97);

ConfigurationBuilder cb98= new ConfigurationBuilder();
cb98.setOAuthConsumerKey(consumerKey98);
cb98.setOAuthConsumerSecret(consumerSecret98);
cb98.setOAuthAccessToken(twitterToken98);
cb98.setOAuthAccessTokenSecret(twitterSecret98);

ConfigurationBuilder cb99= new ConfigurationBuilder();
cb99.setOAuthConsumerKey(consumerKey99);
cb99.setOAuthConsumerSecret(consumerSecret99);
cb99.setOAuthAccessToken(twitterToken99);
cb99.setOAuthAccessTokenSecret(twitterSecret99);

ConfigurationBuilder cb100= new ConfigurationBuilder();
cb100.setOAuthConsumerKey(consumerKey100);
cb100.setOAuthConsumerSecret(consumerSecret100);
cb100.setOAuthAccessToken(twitterToken100);
cb100.setOAuthAccessTokenSecret(twitterSecret100);

ConfigurationBuilder cb101= new ConfigurationBuilder();
cb101.setOAuthConsumerKey(consumerKey101);
cb101.setOAuthConsumerSecret(consumerSecret101);
cb101.setOAuthAccessToken(twitterToken101);
cb101.setOAuthAccessTokenSecret(twitterSecret101);

ConfigurationBuilder cb102= new ConfigurationBuilder();
cb102.setOAuthConsumerKey(consumerKey102);
cb102.setOAuthConsumerSecret(consumerSecret102);
cb102.setOAuthAccessToken(twitterToken102);
cb102.setOAuthAccessTokenSecret(twitterSecret102);

ConfigurationBuilder cb103= new ConfigurationBuilder();
cb103.setOAuthConsumerKey(consumerKey103);
cb103.setOAuthConsumerSecret(consumerSecret103);
cb103.setOAuthAccessToken(twitterToken103);
cb103.setOAuthAccessTokenSecret(twitterSecret103);

ConfigurationBuilder cb104= new ConfigurationBuilder();
cb104.setOAuthConsumerKey(consumerKey104);
cb104.setOAuthConsumerSecret(consumerSecret104);
cb104.setOAuthAccessToken(twitterToken104);
cb104.setOAuthAccessTokenSecret(twitterSecret104);

ConfigurationBuilder cb105= new ConfigurationBuilder();
cb105.setOAuthConsumerKey(consumerKey105);
cb105.setOAuthConsumerSecret(consumerSecret105);
cb105.setOAuthAccessToken(twitterToken105);
cb105.setOAuthAccessTokenSecret(twitterSecret105);

ConfigurationBuilder cb106= new ConfigurationBuilder();
cb106.setOAuthConsumerKey(consumerKey106);
cb106.setOAuthConsumerSecret(consumerSecret106);
cb106.setOAuthAccessToken(twitterToken106);
cb106.setOAuthAccessTokenSecret(twitterSecret106);

ConfigurationBuilder cb107= new ConfigurationBuilder();
cb107.setOAuthConsumerKey(consumerKey107);
cb107.setOAuthConsumerSecret(consumerSecret107);
cb107.setOAuthAccessToken(twitterToken107);
cb107.setOAuthAccessTokenSecret(twitterSecret107);

ConfigurationBuilder cb108= new ConfigurationBuilder();
cb108.setOAuthConsumerKey(consumerKey108);
cb108.setOAuthConsumerSecret(consumerSecret108);
cb108.setOAuthAccessToken(twitterToken108);
cb108.setOAuthAccessTokenSecret(twitterSecret108);

ConfigurationBuilder cb109= new ConfigurationBuilder();
cb109.setOAuthConsumerKey(consumerKey109);
cb109.setOAuthConsumerSecret(consumerSecret109);
cb109.setOAuthAccessToken(twitterToken109);
cb109.setOAuthAccessTokenSecret(twitterSecret109);

ConfigurationBuilder cb110= new ConfigurationBuilder();
cb110.setOAuthConsumerKey(consumerKey110);
cb110.setOAuthConsumerSecret(consumerSecret110);
cb110.setOAuthAccessToken(twitterToken110);
cb110.setOAuthAccessTokenSecret(twitterSecret110);

ConfigurationBuilder cb111= new ConfigurationBuilder();
cb111.setOAuthConsumerKey(consumerKey111);
cb111.setOAuthConsumerSecret(consumerSecret111);
cb111.setOAuthAccessToken(twitterToken111);
cb111.setOAuthAccessTokenSecret(twitterSecret111);

ConfigurationBuilder cb112= new ConfigurationBuilder();
cb112.setOAuthConsumerKey(consumerKey112);
cb112.setOAuthConsumerSecret(consumerSecret112);
cb112.setOAuthAccessToken(twitterToken112);
cb112.setOAuthAccessTokenSecret(twitterSecret112);

ConfigurationBuilder cb113= new ConfigurationBuilder();
cb113.setOAuthConsumerKey(consumerKey113);
cb113.setOAuthConsumerSecret(consumerSecret113);
cb113.setOAuthAccessToken(twitterToken113);
cb113.setOAuthAccessTokenSecret(twitterSecret113);

ConfigurationBuilder cb114= new ConfigurationBuilder();
cb114.setOAuthConsumerKey(consumerKey114);
cb114.setOAuthConsumerSecret(consumerSecret114);
cb114.setOAuthAccessToken(twitterToken114);
cb114.setOAuthAccessTokenSecret(twitterSecret114);

ConfigurationBuilder cb115= new ConfigurationBuilder();
cb115.setOAuthConsumerKey(consumerKey115);
cb115.setOAuthConsumerSecret(consumerSecret115);
cb115.setOAuthAccessToken(twitterToken115);
cb115.setOAuthAccessTokenSecret(twitterSecret115);

ConfigurationBuilder cb116= new ConfigurationBuilder();
cb116.setOAuthConsumerKey(consumerKey116);
cb116.setOAuthConsumerSecret(consumerSecret116);
cb116.setOAuthAccessToken(twitterToken116);
cb116.setOAuthAccessTokenSecret(twitterSecret116);

ConfigurationBuilder cb117= new ConfigurationBuilder();
cb117.setOAuthConsumerKey(consumerKey117);
cb117.setOAuthConsumerSecret(consumerSecret117);
cb117.setOAuthAccessToken(twitterToken117);
cb117.setOAuthAccessTokenSecret(twitterSecret117);

ConfigurationBuilder cb118= new ConfigurationBuilder();
cb118.setOAuthConsumerKey(consumerKey118);
cb118.setOAuthConsumerSecret(consumerSecret118);
cb118.setOAuthAccessToken(twitterToken118);
cb118.setOAuthAccessTokenSecret(twitterSecret118);

ConfigurationBuilder cb119= new ConfigurationBuilder();
cb119.setOAuthConsumerKey(consumerKey119);
cb119.setOAuthConsumerSecret(consumerSecret119);
cb119.setOAuthAccessToken(twitterToken119);
cb119.setOAuthAccessTokenSecret(twitterSecret119);

ConfigurationBuilder cb120= new ConfigurationBuilder();
cb120.setOAuthConsumerKey(consumerKey120);
cb120.setOAuthConsumerSecret(consumerSecret120);
cb120.setOAuthAccessToken(twitterToken120);
cb120.setOAuthAccessTokenSecret(twitterSecret120);

ConfigurationBuilder cb121= new ConfigurationBuilder();
cb121.setOAuthConsumerKey(consumerKey121);
cb121.setOAuthConsumerSecret(consumerSecret121);
cb121.setOAuthAccessToken(twitterToken121);
cb121.setOAuthAccessTokenSecret(twitterSecret121);

ConfigurationBuilder cb122= new ConfigurationBuilder();
cb122.setOAuthConsumerKey(consumerKey122);
cb122.setOAuthConsumerSecret(consumerSecret122);
cb122.setOAuthAccessToken(twitterToken122);
cb122.setOAuthAccessTokenSecret(twitterSecret122);

ConfigurationBuilder cb123= new ConfigurationBuilder();
cb123.setOAuthConsumerKey(consumerKey123);
cb123.setOAuthConsumerSecret(consumerSecret123);
cb123.setOAuthAccessToken(twitterToken123);
cb123.setOAuthAccessTokenSecret(twitterSecret123);

ConfigurationBuilder cb124= new ConfigurationBuilder();
cb124.setOAuthConsumerKey(consumerKey124);
cb124.setOAuthConsumerSecret(consumerSecret124);
cb124.setOAuthAccessToken(twitterToken124);
cb124.setOAuthAccessTokenSecret(twitterSecret124);

ConfigurationBuilder cb125= new ConfigurationBuilder();
cb125.setOAuthConsumerKey(consumerKey125);
cb125.setOAuthConsumerSecret(consumerSecret125);
cb125.setOAuthAccessToken(twitterToken125);
cb125.setOAuthAccessTokenSecret(twitterSecret125);

ConfigurationBuilder cb126= new ConfigurationBuilder();
cb126.setOAuthConsumerKey(consumerKey126);
cb126.setOAuthConsumerSecret(consumerSecret126);
cb126.setOAuthAccessToken(twitterToken126);
cb126.setOAuthAccessTokenSecret(twitterSecret126);

ConfigurationBuilder cb127= new ConfigurationBuilder();
cb127.setOAuthConsumerKey(consumerKey127);
cb127.setOAuthConsumerSecret(consumerSecret127);
cb127.setOAuthAccessToken(twitterToken127);
cb127.setOAuthAccessTokenSecret(twitterSecret127);

ConfigurationBuilder cb128= new ConfigurationBuilder();
cb128.setOAuthConsumerKey(consumerKey128);
cb128.setOAuthConsumerSecret(consumerSecret128);
cb128.setOAuthAccessToken(twitterToken128);
cb128.setOAuthAccessTokenSecret(twitterSecret128);

ConfigurationBuilder cb129= new ConfigurationBuilder();
cb129.setOAuthConsumerKey(consumerKey129);
cb129.setOAuthConsumerSecret(consumerSecret129);
cb129.setOAuthAccessToken(twitterToken129);
cb129.setOAuthAccessTokenSecret(twitterSecret129);

ConfigurationBuilder cb130= new ConfigurationBuilder();
cb130.setOAuthConsumerKey(consumerKey130);
cb130.setOAuthConsumerSecret(consumerSecret130);
cb130.setOAuthAccessToken(twitterToken130);
cb130.setOAuthAccessTokenSecret(twitterSecret130);

ConfigurationBuilder cb131= new ConfigurationBuilder();
cb131.setOAuthConsumerKey(consumerKey131);
cb131.setOAuthConsumerSecret(consumerSecret131);
cb131.setOAuthAccessToken(twitterToken131);
cb131.setOAuthAccessTokenSecret(twitterSecret131);

ConfigurationBuilder cb132= new ConfigurationBuilder();
cb132.setOAuthConsumerKey(consumerKey132);
cb132.setOAuthConsumerSecret(consumerSecret132);
cb132.setOAuthAccessToken(twitterToken132);
cb132.setOAuthAccessTokenSecret(twitterSecret132);

ConfigurationBuilder cb133= new ConfigurationBuilder();
cb133.setOAuthConsumerKey(consumerKey133);
cb133.setOAuthConsumerSecret(consumerSecret133);
cb133.setOAuthAccessToken(twitterToken133);
cb133.setOAuthAccessTokenSecret(twitterSecret133);

ConfigurationBuilder cb134= new ConfigurationBuilder();
cb134.setOAuthConsumerKey(consumerKey134);
cb134.setOAuthConsumerSecret(consumerSecret134);
cb134.setOAuthAccessToken(twitterToken134);
cb134.setOAuthAccessTokenSecret(twitterSecret134);

ConfigurationBuilder cb135= new ConfigurationBuilder();
cb135.setOAuthConsumerKey(consumerKey135);
cb135.setOAuthConsumerSecret(consumerSecret135);
cb135.setOAuthAccessToken(twitterToken135);
cb135.setOAuthAccessTokenSecret(twitterSecret135);

ConfigurationBuilder cb136= new ConfigurationBuilder();
cb136.setOAuthConsumerKey(consumerKey136);
cb136.setOAuthConsumerSecret(consumerSecret136);
cb136.setOAuthAccessToken(twitterToken136);
cb136.setOAuthAccessTokenSecret(twitterSecret136);

ConfigurationBuilder cb137= new ConfigurationBuilder();
cb137.setOAuthConsumerKey(consumerKey137);
cb137.setOAuthConsumerSecret(consumerSecret137);
cb137.setOAuthAccessToken(twitterToken137);
cb137.setOAuthAccessTokenSecret(twitterSecret137);

ConfigurationBuilder cb138= new ConfigurationBuilder();
cb138.setOAuthConsumerKey(consumerKey138);
cb138.setOAuthConsumerSecret(consumerSecret138);
cb138.setOAuthAccessToken(twitterToken138);
cb138.setOAuthAccessTokenSecret(twitterSecret138);

ConfigurationBuilder cb139= new ConfigurationBuilder();
cb139.setOAuthConsumerKey(consumerKey139);
cb139.setOAuthConsumerSecret(consumerSecret139);
cb139.setOAuthAccessToken(twitterToken139);
cb139.setOAuthAccessTokenSecret(twitterSecret139);

ConfigurationBuilder cb140= new ConfigurationBuilder();
cb140.setOAuthConsumerKey(consumerKey140);
cb140.setOAuthConsumerSecret(consumerSecret140);
cb140.setOAuthAccessToken(twitterToken140);
cb140.setOAuthAccessTokenSecret(twitterSecret140);

ConfigurationBuilder cb141= new ConfigurationBuilder();
cb141.setOAuthConsumerKey(consumerKey141);
cb141.setOAuthConsumerSecret(consumerSecret141);
cb141.setOAuthAccessToken(twitterToken141);
cb141.setOAuthAccessTokenSecret(twitterSecret141);

ConfigurationBuilder cb142= new ConfigurationBuilder();
cb142.setOAuthConsumerKey(consumerKey142);
cb142.setOAuthConsumerSecret(consumerSecret142);
cb142.setOAuthAccessToken(twitterToken142);
cb142.setOAuthAccessTokenSecret(twitterSecret142);



Twitter twitter1 = new TwitterFactory(cb1.build()).getInstance();
Twitter twitter2 = new TwitterFactory(cb2.build()).getInstance();
Twitter twitter3 = new TwitterFactory(cb3.build()).getInstance();
Twitter twitter4 = new TwitterFactory(cb4.build()).getInstance();
Twitter twitter5 = new TwitterFactory(cb5.build()).getInstance();
Twitter twitter6 = new TwitterFactory(cb6.build()).getInstance();
Twitter twitter7 = new TwitterFactory(cb7.build()).getInstance();
Twitter twitter8 = new TwitterFactory(cb8.build()).getInstance();
Twitter twitter9 = new TwitterFactory(cb9.build()).getInstance();
Twitter twitter10 = new TwitterFactory(cb10.build()).getInstance();
Twitter twitter11 = new TwitterFactory(cb11.build()).getInstance();
Twitter twitter12 = new TwitterFactory(cb12.build()).getInstance();
Twitter twitter13 = new TwitterFactory(cb13.build()).getInstance();
Twitter twitter14 = new TwitterFactory(cb14.build()).getInstance();
Twitter twitter15 = new TwitterFactory(cb15.build()).getInstance();
Twitter twitter16 = new TwitterFactory(cb16.build()).getInstance();
Twitter twitter17 = new TwitterFactory(cb17.build()).getInstance();
Twitter twitter18 = new TwitterFactory(cb18.build()).getInstance();
Twitter twitter19 = new TwitterFactory(cb19.build()).getInstance();
Twitter twitter20 = new TwitterFactory(cb20.build()).getInstance();
Twitter twitter21 = new TwitterFactory(cb21.build()).getInstance();
Twitter twitter22 = new TwitterFactory(cb22.build()).getInstance();
Twitter twitter23 = new TwitterFactory(cb23.build()).getInstance();
Twitter twitter24 = new TwitterFactory(cb24.build()).getInstance();
Twitter twitter25 = new TwitterFactory(cb25.build()).getInstance();
Twitter twitter26 = new TwitterFactory(cb26.build()).getInstance();
Twitter twitter27 = new TwitterFactory(cb27.build()).getInstance();
Twitter twitter28 = new TwitterFactory(cb28.build()).getInstance();
Twitter twitter29 = new TwitterFactory(cb29.build()).getInstance();
Twitter twitter30 = new TwitterFactory(cb30.build()).getInstance();
Twitter twitter31 = new TwitterFactory(cb31.build()).getInstance();
Twitter twitter32 = new TwitterFactory(cb32.build()).getInstance();
Twitter twitter33 = new TwitterFactory(cb33.build()).getInstance();
Twitter twitter34 = new TwitterFactory(cb34.build()).getInstance();
Twitter twitter35 = new TwitterFactory(cb35.build()).getInstance();
Twitter twitter36 = new TwitterFactory(cb36.build()).getInstance();
Twitter twitter37 = new TwitterFactory(cb37.build()).getInstance();
Twitter twitter38 = new TwitterFactory(cb38.build()).getInstance();
Twitter twitter39 = new TwitterFactory(cb39.build()).getInstance();
Twitter twitter40 = new TwitterFactory(cb40.build()).getInstance();
Twitter twitter41 = new TwitterFactory(cb41.build()).getInstance();
Twitter twitter42 = new TwitterFactory(cb42.build()).getInstance();
Twitter twitter43 = new TwitterFactory(cb43.build()).getInstance();
Twitter twitter44 = new TwitterFactory(cb44.build()).getInstance();
Twitter twitter45 = new TwitterFactory(cb45.build()).getInstance();
Twitter twitter46 = new TwitterFactory(cb46.build()).getInstance();
Twitter twitter47 = new TwitterFactory(cb47.build()).getInstance();
Twitter twitter48 = new TwitterFactory(cb48.build()).getInstance();
Twitter twitter49 = new TwitterFactory(cb49.build()).getInstance();
Twitter twitter50 = new TwitterFactory(cb50.build()).getInstance();
Twitter twitter51 = new TwitterFactory(cb51.build()).getInstance();
Twitter twitter52 = new TwitterFactory(cb52.build()).getInstance();
Twitter twitter53 = new TwitterFactory(cb53.build()).getInstance();
Twitter twitter54 = new TwitterFactory(cb54.build()).getInstance();
Twitter twitter55 = new TwitterFactory(cb55.build()).getInstance();
Twitter twitter56 = new TwitterFactory(cb56.build()).getInstance();
Twitter twitter57 = new TwitterFactory(cb57.build()).getInstance();
Twitter twitter58 = new TwitterFactory(cb58.build()).getInstance();
Twitter twitter59 = new TwitterFactory(cb59.build()).getInstance();
Twitter twitter60 = new TwitterFactory(cb60.build()).getInstance();
Twitter twitter61 = new TwitterFactory(cb61.build()).getInstance();
Twitter twitter62 = new TwitterFactory(cb62.build()).getInstance();
Twitter twitter63 = new TwitterFactory(cb63.build()).getInstance();
Twitter twitter64 = new TwitterFactory(cb64.build()).getInstance();
Twitter twitter65 = new TwitterFactory(cb65.build()).getInstance();
Twitter twitter66 = new TwitterFactory(cb66.build()).getInstance();
Twitter twitter67 = new TwitterFactory(cb67.build()).getInstance();
Twitter twitter68 = new TwitterFactory(cb68.build()).getInstance();
Twitter twitter69 = new TwitterFactory(cb69.build()).getInstance();
Twitter twitter70 = new TwitterFactory(cb70.build()).getInstance();
Twitter twitter71 = new TwitterFactory(cb71.build()).getInstance();
Twitter twitter72 = new TwitterFactory(cb72.build()).getInstance();
Twitter twitter73 = new TwitterFactory(cb73.build()).getInstance();
Twitter twitter74 = new TwitterFactory(cb74.build()).getInstance();
Twitter twitter75 = new TwitterFactory(cb75.build()).getInstance();
Twitter twitter76 = new TwitterFactory(cb76.build()).getInstance();
Twitter twitter77 = new TwitterFactory(cb77.build()).getInstance();
Twitter twitter78 = new TwitterFactory(cb78.build()).getInstance();
Twitter twitter79 = new TwitterFactory(cb79.build()).getInstance();
Twitter twitter80 = new TwitterFactory(cb80.build()).getInstance();
Twitter twitter81 = new TwitterFactory(cb81.build()).getInstance();
Twitter twitter82 = new TwitterFactory(cb82.build()).getInstance();
Twitter twitter83 = new TwitterFactory(cb83.build()).getInstance();
Twitter twitter84 = new TwitterFactory(cb84.build()).getInstance();
Twitter twitter85 = new TwitterFactory(cb85.build()).getInstance();
Twitter twitter86 = new TwitterFactory(cb86.build()).getInstance();
Twitter twitter87 = new TwitterFactory(cb87.build()).getInstance();
Twitter twitter88 = new TwitterFactory(cb88.build()).getInstance();
Twitter twitter89 = new TwitterFactory(cb89.build()).getInstance();
Twitter twitter90 = new TwitterFactory(cb90.build()).getInstance();
Twitter twitter91 = new TwitterFactory(cb91.build()).getInstance();
Twitter twitter92 = new TwitterFactory(cb92.build()).getInstance();
Twitter twitter93 = new TwitterFactory(cb93.build()).getInstance();
Twitter twitter94 = new TwitterFactory(cb94.build()).getInstance();
Twitter twitter95 = new TwitterFactory(cb95.build()).getInstance();
Twitter twitter96 = new TwitterFactory(cb96.build()).getInstance();
Twitter twitter97 = new TwitterFactory(cb97.build()).getInstance();
Twitter twitter98 = new TwitterFactory(cb98.build()).getInstance();
Twitter twitter99 = new TwitterFactory(cb99.build()).getInstance();
Twitter twitter100 = new TwitterFactory(cb100.build()).getInstance();
Twitter twitter101 = new TwitterFactory(cb101.build()).getInstance();
Twitter twitter102 = new TwitterFactory(cb102.build()).getInstance();
Twitter twitter103 = new TwitterFactory(cb103.build()).getInstance();
Twitter twitter104 = new TwitterFactory(cb104.build()).getInstance();
Twitter twitter105 = new TwitterFactory(cb105.build()).getInstance();
Twitter twitter106 = new TwitterFactory(cb106.build()).getInstance();
Twitter twitter107 = new TwitterFactory(cb107.build()).getInstance();
Twitter twitter108 = new TwitterFactory(cb108.build()).getInstance();
Twitter twitter109 = new TwitterFactory(cb109.build()).getInstance();
Twitter twitter110 = new TwitterFactory(cb110.build()).getInstance();
Twitter twitter111 = new TwitterFactory(cb111.build()).getInstance();
Twitter twitter112 = new TwitterFactory(cb112.build()).getInstance();
Twitter twitter113 = new TwitterFactory(cb113.build()).getInstance();
Twitter twitter114 = new TwitterFactory(cb114.build()).getInstance();
Twitter twitter115 = new TwitterFactory(cb115.build()).getInstance();
Twitter twitter116 = new TwitterFactory(cb116.build()).getInstance();
Twitter twitter117 = new TwitterFactory(cb117.build()).getInstance();
Twitter twitter118 = new TwitterFactory(cb118.build()).getInstance();
Twitter twitter119 = new TwitterFactory(cb119.build()).getInstance();
Twitter twitter120 = new TwitterFactory(cb120.build()).getInstance();
Twitter twitter121 = new TwitterFactory(cb121.build()).getInstance();
Twitter twitter122 = new TwitterFactory(cb122.build()).getInstance();
Twitter twitter123 = new TwitterFactory(cb123.build()).getInstance();
Twitter twitter124 = new TwitterFactory(cb124.build()).getInstance();
Twitter twitter125 = new TwitterFactory(cb125.build()).getInstance();
Twitter twitter126 = new TwitterFactory(cb126.build()).getInstance();
Twitter twitter127 = new TwitterFactory(cb127.build()).getInstance();
Twitter twitter128 = new TwitterFactory(cb128.build()).getInstance();
Twitter twitter129 = new TwitterFactory(cb129.build()).getInstance();
Twitter twitter130 = new TwitterFactory(cb130.build()).getInstance();
Twitter twitter131 = new TwitterFactory(cb131.build()).getInstance();
Twitter twitter132 = new TwitterFactory(cb132.build()).getInstance();
Twitter twitter133 = new TwitterFactory(cb133.build()).getInstance();
Twitter twitter134 = new TwitterFactory(cb134.build()).getInstance();
Twitter twitter135 = new TwitterFactory(cb135.build()).getInstance();
Twitter twitter136 = new TwitterFactory(cb136.build()).getInstance();
Twitter twitter137 = new TwitterFactory(cb137.build()).getInstance();
Twitter twitter138 = new TwitterFactory(cb138.build()).getInstance();
Twitter twitter139 = new TwitterFactory(cb139.build()).getInstance();
Twitter twitter140 = new TwitterFactory(cb140.build()).getInstance();
Twitter twitter141 = new TwitterFactory(cb141.build()).getInstance();
Twitter twitter142 = new TwitterFactory(cb142.build()).getInstance();
        l = lstatus;
        int limtcount=0;
        ArrayList temp = new ArrayList();
        try {
            String usr = usrName;
            //String fname = usrName + ".txt";
            //System.out.println(fname);
            long cursor = -1;
//            PagableResponseList<User> pagableFollowings;
//            do {
//                pagableFollowings = twitter1.getFriendsList(Long.parseLong(usr), cursor);
//                for (User user : pagableFollowings) {
//                    System.out.println(user.getId()+" "+cursor);
//                }
//                System.out.println(pagableFollowings.getNextCursor());
//            } while ((cursor = pagableFollowings.getNextCursor()) != 0);

            // get followings
            System.out.println("followings of"+usr);
            User user1 = null;
            cursor = -1;
            l = lstatus;
            System.out.println("lstatus"+l);
            
            System.out.println("sleep1");
            if(j>1){
            Thread.sleep(1000);
            }
           // BufferedWriter bout = new BufferedWriter(new FileWriter("/home/pykl/Desktop/snap/" + usrName + ".txt", true));
           long start_time = System.currentTimeMillis();
	   long end_time;	
	   long total_time;
            PagableResponseList<User> pagablefollowings = null;
            Twitter twitter = null;
            
            do {
                if (l == 1) {
                    System.out.println(1);
                    Thread.sleep(1000);
                    twitter = twitter1;
                } else if (l == 2) {
                    System.out.println(2);
                    Thread.sleep(1000);
                    twitter = twitter2;
                } else if (l == 3) {
                    System.out.println(3);
                    Thread.sleep(1000);
                    twitter = twitter3;
                } else if (l == 4) {
                    System.out.println(4);
                    Thread.sleep(1000);
                    twitter = twitter4;
                } else if (l == 5) {
                    System.out.println(5);
                    Thread.sleep(1000);
                    twitter = twitter5;
                } else if (l == 6) {
                    System.out.println(6);
                    Thread.sleep(1000);
                    twitter = twitter6;
                } else if (l == 7) {
                    System.out.println(7);
                    Thread.sleep(1000);
                    twitter = twitter7;
                } else if (l == 8) {
                    System.out.println(8);
                    Thread.sleep(1000);
                    twitter = twitter8;
                } else if (l == 9) {
                    System.out.println(9);
                    Thread.sleep(1000);
                    twitter = twitter9;
                } else if (l == 10) {
                    System.out.println(10);
                    Thread.sleep(1000);
                    twitter = twitter10;
                } else if (l == 11) {
                    System.out.println(11);
                    Thread.sleep(1000);
                    twitter = twitter11;
                } else if (l == 12) {
                    System.out.println(12);
                    Thread.sleep(1000);
                    twitter = twitter12;
                } else if (l == 13) {
                    System.out.println(13);
                    Thread.sleep(1000);
                    twitter = twitter13;
                } else if (l == 14) {
                    System.out.println(14);
                    Thread.sleep(1000);
                    twitter = twitter14;
                } else if (l == 15) {
                    System.out.println(15);
                    Thread.sleep(1000);
                    twitter = twitter15;
                } else if (l == 16) {
                    System.out.println(16);
                    Thread.sleep(1000);
                    twitter = twitter16;
                } else if (l == 17) {
                    System.out.println(17);
                    Thread.sleep(1000);
                    twitter = twitter17;
                } else if (l == 18) {
                    System.out.println(18);
                    Thread.sleep(1000);
                    twitter = twitter18;
                } else if (l == 19) {
                    System.out.println(19);
                    Thread.sleep(1000);
                    twitter = twitter19;
                } else if (l == 20) {
                    System.out.println(20);
                    Thread.sleep(1000);
                    twitter = twitter20;
                } else if (l == 21) {
                    System.out.println(21);
                    Thread.sleep(1000);
                    twitter = twitter21;
                } else if (l == 22) {
                    System.out.println(22);
                    Thread.sleep(1000);
                    twitter = twitter22;
                } else if (l == 23) {
                    System.out.println(23);
                    Thread.sleep(1000);
                    twitter = twitter23;
                } else if (l == 24) {
                    System.out.println(24);
                    Thread.sleep(1000);
                    twitter = twitter24;
                } else if (l == 25) {
                    System.out.println(25);
                    Thread.sleep(1000);
                    twitter = twitter25;
                } else if (l == 26) {
                    System.out.println(26);
                    Thread.sleep(1000);
                    twitter = twitter26;
                } else if (l == 27) {
                    System.out.println(27);
                    Thread.sleep(1000);
                    twitter = twitter27;
                } else if (l == 28) {
                    System.out.println(28);
                    Thread.sleep(1000);
                    twitter = twitter28;
                } else if (l == 29) {
                    System.out.println(29);
                    Thread.sleep(1000);
                    twitter = twitter29;
                } else if (l == 30) {
                    System.out.println(30);
                    Thread.sleep(1000);
                    twitter = twitter30;
                } else if (l == 31) {
                    System.out.println(31);
                    Thread.sleep(1000);
                    twitter = twitter31;
                } else if (l == 32) {
                    System.out.println(32);
                    Thread.sleep(1000);
                    twitter = twitter32;
                } else if (l == 33) {
                    System.out.println(33);
                    Thread.sleep(1000);
                    twitter = twitter33;
                } else if (l == 34) {
                    System.out.println(34);
                    Thread.sleep(1000);
                    twitter = twitter34;
                } else if (l == 35) {
                    System.out.println(35);
                    Thread.sleep(1000);
                    twitter = twitter35;
                } else if (l == 36) {
                    System.out.println(36);
                    Thread.sleep(1000);
                    twitter = twitter36;
                } else if (l == 37) {
                    System.out.println(37);
                    Thread.sleep(1000);
                    twitter = twitter37;
                } else if (l == 38) {
                    System.out.println(38);
                    Thread.sleep(1000);
                    twitter = twitter38;
                } else if (l == 39) {
                    System.out.println(39);
                    Thread.sleep(1000);
                    twitter = twitter39;
                } else if (l == 40) {
                    System.out.println(40);
                    Thread.sleep(1000);
                    twitter = twitter40;
                } else if (l == 41) {
                    System.out.println(41);
                    Thread.sleep(1000);
                    twitter = twitter41;
                } else if (l == 42) {
                    System.out.println(42);
                    Thread.sleep(1000);
                    twitter = twitter42;
                } else if (l == 43) {
                    System.out.println(43);
                    Thread.sleep(1000);
                    twitter = twitter43;
                } else if (l == 44) {
                    System.out.println(44);
                    Thread.sleep(1000);
                    twitter = twitter44;
                } else if (l == 45) {
                    System.out.println(45);
                    Thread.sleep(1000);
                    twitter = twitter45;
                } else if (l == 46) {
                    System.out.println(46);
                    Thread.sleep(1000);
                    twitter = twitter46;
                } else if (l == 47) {
                    System.out.println(47);
                    Thread.sleep(1000);
                    twitter = twitter47;
                } else if (l == 48) {
                    System.out.println(48);
                    Thread.sleep(1000);
                    twitter = twitter48;
                } else if (l == 49) {
                    System.out.println(49);
                    Thread.sleep(1000);
                    twitter = twitter49;
                } else if (l == 50) {
                    System.out.println(50);
                    Thread.sleep(1000);
                    twitter = twitter50;
                } else if (l == 51) {
                    System.out.println(51);
                    Thread.sleep(1000);
                    twitter = twitter51;
                } else if (l == 52) {
                    System.out.println(52);
                    Thread.sleep(1000);
                    twitter = twitter52;
                } else if (l == 53) {
                    System.out.println(53);
                    Thread.sleep(1000);
                    twitter = twitter53;
                } else if (l == 54) {
                    System.out.println(54);
                    Thread.sleep(1000);
                    twitter = twitter54;
                } else if (l == 55) {
                    System.out.println(55);
                    Thread.sleep(1000);
                    twitter = twitter55;
                } else if (l == 56) {
                    System.out.println(56);
                    Thread.sleep(1000);
                    twitter = twitter56;
                } else if (l == 57) {
                    System.out.println(57);
                    Thread.sleep(1000);
                    twitter = twitter57;
                } else if (l == 58) {
                    System.out.println(58);
                    Thread.sleep(1000);
                    twitter = twitter58;
                } else if (l == 59) {
                    System.out.println(59);
                    Thread.sleep(1000);
                    twitter = twitter59;
                } else if (l == 60) {
                    System.out.println(60);
                    Thread.sleep(1000);
                    twitter = twitter60;
                } else if (l == 61) {
                    System.out.println(61);
                    Thread.sleep(1000);
                    twitter = twitter61;
                } else if (l == 62) {
                    System.out.println(62);
                    Thread.sleep(1000);
                    twitter = twitter62;
                } else if (l == 63) {
                    System.out.println(63);
                    Thread.sleep(1000);
                    twitter = twitter63;
                } else if (l == 64) {
                    System.out.println(64);
                    Thread.sleep(1000);
                    twitter = twitter64;
                } else if (l == 65) {
                    System.out.println(65);
                    Thread.sleep(1000);
                    twitter = twitter65;
                } else if (l == 66) {
                    System.out.println(66);
                    Thread.sleep(1000);
                    twitter = twitter66;
                } else if (l == 67) {
                    System.out.println(67);
                    Thread.sleep(1000);
                    twitter = twitter67;
                } else if (l == 68) {
                    System.out.println(68);
                    Thread.sleep(1000);
                    twitter = twitter68;
                } else if (l == 69) {
                    System.out.println(69);
                    Thread.sleep(1000);
                    twitter = twitter69;
                } else if (l == 70) {
                    System.out.println(70);
                    Thread.sleep(1000);
                    twitter = twitter70;
                } else if (l == 71) {
                    System.out.println(71);
                    Thread.sleep(1000);
                    twitter = twitter71;
                } else if (l == 72) {
                    System.out.println(72);
                    Thread.sleep(1000);
                    twitter = twitter72;
                } else if (l == 73) {
                    System.out.println(73);
                    Thread.sleep(1000);
                    twitter = twitter73;
                } else if (l == 74) {
                    System.out.println(74);
                    Thread.sleep(1000);
                    twitter = twitter74;
                } else if (l == 75) {
                    System.out.println(75);
                    Thread.sleep(1000);
                    twitter = twitter75;
                } else if (l == 76) {
                    System.out.println(76);
                    Thread.sleep(1000);
                    twitter = twitter76;
                } else if (l == 77) {
                    System.out.println(77);
                    Thread.sleep(1000);
                    twitter = twitter77;
                } else if (l == 78) {
                    System.out.println(78);
                    Thread.sleep(1000);
                    twitter = twitter78;
                } else if (l == 79) {
                    System.out.println(79);
                    Thread.sleep(1000);
                    twitter = twitter79;
                } else if (l == 80) {
                    System.out.println(80);
                    Thread.sleep(1000);
                    twitter = twitter80;
                } else if (l == 81) {
                    System.out.println(81);
                    Thread.sleep(1000);
                    twitter = twitter81;
                } else if (l == 82) {
                    System.out.println(82);
                    Thread.sleep(1000);
                    twitter = twitter82;
                } else if (l == 83) {
                    System.out.println(83);
                    Thread.sleep(1000);
                    twitter = twitter83;
                } else if (l == 84) {
                    System.out.println(84);
                    Thread.sleep(1000);
                    twitter = twitter84;
                } else if (l == 85) {
                    System.out.println(85);
                    Thread.sleep(1000);
                    twitter = twitter85;
                } else if (l == 86) {
                    System.out.println(86);
                    Thread.sleep(1000);
                    twitter = twitter86;
                } else if (l == 87) {
                    System.out.println(87);
                    Thread.sleep(1000);
                    twitter = twitter87;
                } else if (l == 88) {
                    System.out.println(88);
                    Thread.sleep(1000);
                    twitter = twitter88;
                } else if (l == 89) {
                    System.out.println(89);
                    Thread.sleep(1000);
                    twitter = twitter89;
                } else if (l == 90) {
                    System.out.println(90);
                    Thread.sleep(1000);
                    twitter = twitter90;
                } else if (l == 91) {
                    System.out.println(91);
                    Thread.sleep(1000);
                    twitter = twitter91;
                } else if (l == 92) {
                    System.out.println(92);
                    Thread.sleep(1000);
                    twitter = twitter92;
                } else if (l == 93) {
                    System.out.println(93);
                    Thread.sleep(1000);
                    twitter = twitter93;
                } else if (l == 94) {
                    System.out.println(94);
                    Thread.sleep(1000);
                    twitter = twitter94;
                } else if (l == 95) {
                    System.out.println(95);
                    Thread.sleep(1000);
                    twitter = twitter95;
                } else if (l == 96) {
                    System.out.println(96);
                    Thread.sleep(1000);
                    twitter = twitter96;
                } else if (l == 97) {
                    System.out.println(97);
                    Thread.sleep(1000);
                    twitter = twitter97;
                } else if (l == 98) {
                    System.out.println(98);
                    Thread.sleep(1000);
                    twitter = twitter98;
                } else if (l == 99) {
                    System.out.println(99);
                    Thread.sleep(1000);
                    twitter = twitter99;
                } else if (l == 100) {
                    System.out.println(100);
                    Thread.sleep(1000);
                    twitter = twitter100;
                } else if (l == 101) {
                    System.out.println(101);
                    Thread.sleep(1000);
                    twitter = twitter101;
                } else if (l == 102) {
                    System.out.println(102);
                    Thread.sleep(1000);
                    twitter = twitter102;
                } else if (l == 103) {
                    System.out.println(103);
                    Thread.sleep(1000);
                    twitter = twitter103;
                } else if (l == 104) {
                    System.out.println(104);
                    Thread.sleep(1000);
                    twitter = twitter104;
                } else if (l == 105) {
                    System.out.println(105);
                    Thread.sleep(1000);
                    twitter = twitter105;
                } else if (l == 106) {
                    System.out.println(106);
                    Thread.sleep(1000);
                    twitter = twitter106;
                } else if (l == 107) {
                    System.out.println(107);
                    Thread.sleep(1000);
                    twitter = twitter107;
                } else if (l == 108) {
                    System.out.println(108);
                    Thread.sleep(1000);
                    twitter = twitter108;
                } else if (l == 109) {
                    System.out.println(109);
                    Thread.sleep(1000);
                    twitter = twitter109;
                } else if (l == 110) {
                    System.out.println(110);
                    Thread.sleep(1000);
                    twitter = twitter110;
                } else if (l == 111) {
                    System.out.println(111);
                    Thread.sleep(1000);
                    twitter = twitter111;
                } else if (l == 112) {
                    System.out.println(112);
                    Thread.sleep(1000);
                    twitter = twitter112;
                } else if (l == 113) {
                    System.out.println(113);
                    Thread.sleep(1000);
                    twitter = twitter113;
                } else if (l == 114) {
                    System.out.println(114);
                    Thread.sleep(1000);
                    twitter = twitter114;
                } else if (l == 115) {
                    System.out.println(115);
                    Thread.sleep(1000);
                    twitter = twitter115;
                } else if (l == 116) {
                    System.out.println(116);
                    Thread.sleep(1000);
                    twitter = twitter116;
                } else if (l == 117) {
                    System.out.println(117);
                    Thread.sleep(1000);
                    twitter = twitter117;
                } else if (l == 118) {
                    System.out.println(118);
                    Thread.sleep(1000);
                    twitter = twitter118;
                } else if (l == 119) {
                    System.out.println(119);
                    Thread.sleep(1000);
                    twitter = twitter119;
                } else if (l == 120) {
                    System.out.println(120);
                    Thread.sleep(1000);
                    twitter = twitter120;
                } else if (l == 121) {
                    System.out.println(121);
                    Thread.sleep(1000);
                    twitter = twitter121;
                } else if (l == 122) {
                    System.out.println(122);
                    Thread.sleep(1000);
                    twitter = twitter122;
                } else if (l == 123) {
                    System.out.println(123);
                    Thread.sleep(1000);
                    twitter = twitter123;
                } else if (l == 124) {
                    System.out.println(124);
                    Thread.sleep(1000);
                    twitter = twitter124;
                } else if (l == 125) {
                    System.out.println(125);
                    Thread.sleep(1000);
                    twitter = twitter125;
                } else if (l == 126) {
                    System.out.println(126);
                    Thread.sleep(1000);
                    twitter = twitter126;
                } else if (l == 127) {
                    System.out.println(127);
                    Thread.sleep(1000);
                    twitter = twitter127;
                } else if (l == 128) {
                    System.out.println(128);
                    Thread.sleep(1000);
                    twitter = twitter128;
                } else if (l == 129) {
                    System.out.println(129);
                    Thread.sleep(1000);
                    twitter = twitter129;
                } else if (l == 130) {
                    System.out.println(130);
                    Thread.sleep(1000);
                    twitter = twitter130;
                } else if (l == 131) {
                    System.out.println(131);
                    Thread.sleep(1000);
                    twitter = twitter131;
                } else if (l == 132) {
                    System.out.println(132);
                    Thread.sleep(1000);
                    twitter = twitter132;
                } else if (l == 133) {
                    System.out.println(133);
                    Thread.sleep(1000);
                    twitter = twitter133;
                } else if (l == 134) {
                    System.out.println(134);
                    Thread.sleep(1000);
                    twitter = twitter134;
                } else if (l == 135) {
                    System.out.println(135);
                    Thread.sleep(1000);
                    twitter = twitter135;
                } else if (l == 136) {
                    System.out.println(136);
                    Thread.sleep(1000);
                    twitter = twitter136;
                } else if (l == 137) {
                    System.out.println(137);
                    Thread.sleep(1000);
                    twitter = twitter137;
                } else if (l == 138) {
                    System.out.println(138);
                    Thread.sleep(1000);
                    twitter = twitter138;
                } else if (l == 139) {
                    System.out.println(139);
                    Thread.sleep(1000);
                    twitter = twitter139;
                } else if (l == 140) {
                    System.out.println(140);
                    Thread.sleep(1000);
                    twitter = twitter140;
                } else if (l == 141) {
                    System.out.println(141);
                    Thread.sleep(1000);
                    twitter = twitter141;
                } else if (l == 142) {
                    System.out.println(142);
                    Thread.sleep(1000);
                    twitter = twitter142;
                } else {
                    System.out.println("1");
                    System.out.println("sleep else");
                    Thread.currentThread().sleep(30000);
                    l = 1;
                    twitter = twitter1;
                }

               
                user1 = twitter.showUser(usr);
                //twitter.getfollowingsList(usr, cursor);
                if(user1.getRateLimitStatus().getRemaining() > 300){
                pagablefollowings = twitter.getFriendsList(usr, cursor);
                }else{
                	System.out.println("Rate Limit Exceeded");
                }
                System.out.println("Followings="+user1.getFriendsCount());
                String limt=""+user1.getRateLimitStatus().getRemaining();
                //limtcount= limtcount+1;
                System.out.println("limt"+limt);
              if(!(limt.equalsIgnoreCase("null"))){
                if ( Integer.parseInt(limt) < 887) {
                    System.out.println("l" + l);
                    if (l < 143) {
                        l = l + 1;
                        //System.out.println("l+1"+l);
                        limtcount=0;
                        //System.out.println("limtcount intiallization"+limtcount);
                    } else {
                        //System.out.println("sleep final");
                        Thread.currentThread().sleep(30000);
                        l = 1;
                    }
                }
                 }else{
                  if (l < 143) {
                        l = l + 1;
                        //System.out.println("l+1"+l);
                    } else {
                        //System.out.println("sleep final");
                        Thread.currentThread().sleep(30000);
                        l = 1;
                    }
                 }

                
                for (User user : pagablefollowings) {
                	String id = null;
                    //System.out.println(user.getId()); // ArrayList<User>
                	
                     id = user.getName() + "";
                	
                	
                   // System.out.println( user.getId()+","+user.getBiggerProfileImageURL());
                    followings.add(id);
                    followingsTname.add(user.getScreenName());
                    //this.followingspic.add(user.getProfileImageURL());
                    
                }
//                int i = 0;
//                while (i < temp.size()) {
//                    System.out.println(usrName + "--" + temp.get(i));
//                    bout.append(temp.get(i).toString());
//                    bout.append("\n");
//                    i++;
//                }
                //temp.clear();
                
            } while ((cursor = pagablefollowings.getNextCursor()) != 0);
           // bout.close();
           int m=0;
          
           long userID = user1.getId();
           
           path_followings = file_path+"\\"+userID+"_followings.txt";   
           BufferedWriter fbw = new BufferedWriter(new FileWriter(path_followings, true));
           String concat_followings = "";
           while(m< followingsTname.size()){
        	   
           System.out.println(followingsTname.get(m));
           m++;
           }
           concat_followings = String.join(",", followingsTname);
           
           System.out.println("followings of "+usrName);
           System.out.println(concat_followings);
           //TwitterDataCrawler.write_to_file(path_followings,concat_followings);
          fbw.close();
        	   
          for(String followings:followingsTname){
          	   TwitterDataCrawler.file_append(path_followings, followings);
          	   
             }
          
          
        } catch (TwitterException e) {
            System.out.println("Twitter Exception Caught"+e.getStatusCode()+"Followings");
            if(e.getStatusCode() == 429) {
            	System.out.println("Making thread to sleep");
            	Thread.currentThread();
				Thread.sleep(30000);
				String writeException = "F:\\Categorized Network\\Twitter_Dataset\\Sudhesh\\Followers\\Extracted_Followers\\Exceptions\\Exception_Following_429.txt";   
		        BufferedWriter fbw = new BufferedWriter(new FileWriter(writeException, true));
		        TwitterDataCrawler.file_append(writeException, usrName);
            }
            
        }
        catch (NullPointerException e) {
            System.out.println("Null Pointer Exception");
////            BufferedWriter nout = new BufferedWriter(new FileWriter("/home/pykl/Desktop/snap/userNull.txt", true));
////            nout.append(usrName);
////            nout.append("\n");
////            nout.close();
//            int m=0;
//            while(m<temp.size()){
//           System.out.println(temp.get(m));
//           m++;
//            }
        }
        
        return l;
    }
   
	
}