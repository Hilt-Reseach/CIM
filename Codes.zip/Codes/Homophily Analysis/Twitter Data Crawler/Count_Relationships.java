import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import au.com.bytecode.opencsv.CSVReader;

public class Count_Relationships {
	
	public void file_read(String file_path){
		int friends = 0,relatives = 0,colleagues = 0,others = 0;
		String friend[], relative[], colleague[], other[];
		String line[];
		try {
			CSVReader reader = new CSVReader(new FileReader(file_path));
		    while((line = reader.readNext()) != null ){
		    	System.out.println("Reading: "+line);
		    	try {
					System.out.println("Uname: "+line[0]);
					System.out.println("Friends: "+line[1]);
					System.out.println("Relatives: "+line[2]);
					System.out.println("Colleagues: "+line[3]);
					System.out.println("Others: "+line[4]);
					friend = line[1].split(",");
					relative = line[2].split(",");
					colleague = line[3].split(",");
					other = line[4].split(",");
					for(int i = 0; i < friend.length; i++){
						if(friend[i].equals("NULL")){
							
						}else{
							friends++;
						}
					}
					for(int i = 0; i < relative.length; i++){
						if(relative[i].equals("NULL")){
							
						}else{
							relatives++;
						}
					}
					for(int i = 0; i < colleague.length; i++){
						if(colleague[i].equals("NULL")){
							
						}else{
							colleagues++;
						}
					}
					for(int i = 0; i < other.length; i++){
						if(other[i].equals("NULL")){
							
						}else{
							others++;
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println("Exception while trying to extract!!!");
				}
		    }
		    System.out.println("Number of friends = "+friends);
		    System.out.println("Number of relatives = "+relatives);
		    System.out.println("Number of colleagues = "+colleagues);
		    System.out.println("Number of others = "+others);
		    reader.close();
		} catch (IOException e) {
			System.out.println("File Not found");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Count_Relationships cr = new Count_Relationships();
		String file_path = "F:\\Categorized Network\\Twitter_Dataset\\Followers_Files\\Followers.txt";
		//String file_path = "F:\\Categorized Network\\Twitter_Dataset\\Followings_Files\\Followings.txt";
		cr.file_read(file_path);
	}

}
