import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import au.com.bytecode.opencsv.CSVReader;

public class Extract_Friends_Relatives_Colleagues {

	public void read_files(String directoryname){
		String[] line = null;
		String[] friends = null;
		String[] relatives = null;
		String[] colleagues = null;
		String[] others = null;
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader(directoryname));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found while reading One hop Followers File");
		}
		
		try {
			while ((line = reader.readNext()) != null) {
				System.out.println("User: "+line[0]);
				System.out.println("Friends: "+line[1]);
				System.out.println("Relatives: "+line[2]);
				System.out.println("Colleagues: "+line[3]);
				System.out.println("Others: "+line[4]);
				friends = line[1].split(",");
				relatives = line[2].split(",");
				colleagues = line[3].split(",");
				others = line[4].split(",");
				
				String dir = "F:\\Categorized Network\\Twitter_Dataset\\Followers_Complete\\"+line[0];
				GetFollowers followers = new GetFollowers();
				GetFollowings followings = new GetFollowings();
				GetStatus status = new GetStatus();
				
				for(String list_friends:friends){
					String friends_dir = dir+"\\Friends\\";
					String friends_dir_Followers = friends_dir+"Followers\\";
					System.out.println("Inside "+friends_dir_Followers);
					
					try {
						followers.get_Followers(friends_dir_Followers, list_friends);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						if(e.toString().contains("java.io.FileNotFoundException")){
							System.out.println("+++++++++++++++++FILE NOT FOUND ++++++++++++++++++++");
						}
					}
				}
				
				for(String list_relatives:relatives){
					System.out.println(list_relatives);
				}
				
				for(String list_colleagues:colleagues){
					System.out.println(list_colleagues);
				}
				
				for(String list_others:others){
					String[] list_others_clean = null;
					list_others_clean = list_others.split(":");
					System.out.println(list_others_clean[0]);
				}
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IOException on read_files");
		}
	}
	
	public void check_file(String path, String userID){
		String file_path = path;
		String Sid = userID;
		
		System.out.println(file_path);
		System.out.println(Sid);
		
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String directoryName = "F:\\Categorized Network\\Twitter_Dataset\\Followers_Files\\Followers.txt";
		Extract_Friends_Relatives_Colleagues efrc = new Extract_Friends_Relatives_Colleagues();
		efrc.read_files(directoryName);
	}

}
