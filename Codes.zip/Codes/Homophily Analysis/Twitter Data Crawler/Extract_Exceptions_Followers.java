
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import au.com.bytecode.opencsv.CSVReader;

public class Extract_Exceptions_Followers {

	int count;
	
	public void read(){

		String path = "F:\\Categorized Network\\Twitter_Dataset\\Extracted_Files\\Followers\\Exception_Follower_Followers.txt";
		String extract_path = "F:\\Categorized Network\\Twitter_Dataset\\Extracted_Data";
		int line_num = 1;
		String[] line;
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader(path));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("(Read) File Not Found:"+path);
		}
		try {
			while ((line = reader.readNext()) != null) {
				System.out.println(line_num);
				line_num++;
				System.out.println("uname :");
				line[0] = line[0].trim();
				split_names(extract_path,line[0]);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Exception caught while reading: "+e.getMessage());
		}	
		
		try {
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("(Read) IO Exception Caught");
		}
		
	}
	
	public void split_names(String file_path,String names) throws FileNotFoundException, IOException, Exception{
		if(names.equals("NULL")){
			System.out.println("Value is Null!!!");
		}
		else
		{
		System.out.println(names);
		String name[] = names.split(",");
		for(int i = 0; i < name.length; i++){
			name[i] = name[i].trim();
			System.out.println("Reading : "+name[i]);
			count++;
			GetFollowers followers = new GetFollowers();
			followers.get_Followers(file_path,name[i]);
			}
		}
	}
	
	public static void main(String args[]){
		
		Extract_Exceptions_Followers eef = new Extract_Exceptions_Followers();
		eef.read();
	}
	
}
