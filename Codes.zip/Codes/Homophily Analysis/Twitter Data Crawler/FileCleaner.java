import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCleaner {
	
	public void file_clean(){
		
		File inputFile = new File("F:\\Categorized Network\\Network\\Followings.csv");
		File newFile = new File("F:\\Categorized Network\\Network\\Followings_Clean.csv");

		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(inputFile));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			System.out.println("File Not found");
		}
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(newFile));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Not able to write");
		}

		String lineToRemove = "NULL,NULL,NULL,NULL";
		String currentLine;

		try {
			while((currentLine = reader.readLine()) != null) {
			    // trim newline when comparing with lineToRemove
			    String trimmedLine = currentLine.trim();
			    if(trimmedLine.contains(lineToRemove)) continue;
			    writer.write(currentLine + System.getProperty("line.separator"));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IO Exception");
		} 
		
		
	}

	public static void main(String args[]){
		
		FileCleaner fc = new FileCleaner();
		fc.file_clean();
		
	}
	
}
