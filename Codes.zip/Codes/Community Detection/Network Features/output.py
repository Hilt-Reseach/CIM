import subprocess
import os
import csv

directory = "/home/research/Documents/Categorized_Network_Analysis/CESNA/cesna_output_zero/"

file_list = []

for filename in os.listdir(directory):
	if "output" in filename:
		print(filename)
		file_list.append(filename)

print(len(file_list))

with open("F1_Measure.csv","w+") as writer:
	for name in file_list:
		with open(name,"r") as f:
			reader = csv.reader(f,delimiter = ":")
			for row in reader:
				print(row[1])
				writer.write(row[1]+"\n")
