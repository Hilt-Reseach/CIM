import subprocess
import os

directory = "/home/research/Documents/Categorized_Network_Analysis/CESNA/cesna_output_zero/"

file_list = []

for filename in os.listdir(directory):
	if filename.endswith(".nodefeatcmtyvv.txt"):
		filename = filename.split(".")
		print(filename[0])
		file_list.append(filename[0])

print(len(file_list))

for user_id in file_list:
	check_path = "/home/research/Documents/Categorized_Network_Analysis/CESNA/cesna_output_zero/CESNA_"+user_id+".txt"
	if os.path.exists(check_path):
		subprocess.call("python F1_communities.py "+user_id+".nodefeatcmtyvv.txt CESNA_"+user_id+".txt",shell=True)
		os.rename("output_f1.txt",user_id+"_output_f1.txt")



