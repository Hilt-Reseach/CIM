import csv

with open("CESNA_P_V.txt") as f:
	reader = csv.reader(f,delimiter = ",")
	for row in reader:
		print(row)
		with open("CESNA_"+row[0]+".txt",'w') as writer:
			for i in row:
				writer.write(i+"\t")
