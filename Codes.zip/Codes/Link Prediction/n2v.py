import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
import scipy.sparse as sp
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.metrics import average_precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score
import pickle
import csv
from preprocessing import mask_test_edges
import node2vec
from gensim.models import Word2Vec

g = nx.Graph() # re-create graph using node indices (0 to num_nodes-1)
'''
with open ('Nodes_Colleagues.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        g.add_node(row[0],open = row[1],conscient = row[2],extrovert = row[3],agree = row[4],neurotic = row[5],
        	ach = row[6], ben = row[7], con = row[8], hed = row[9], pow = row[10], sec = row[11], sd =row[12],
        	sti = row[13], tra = row[14], uni = row[15], male = row[16], female = row[17], a_10 = row[18],
        	a_20 = row[19], a_30 = row[20])
'''
with open ('Network_Friends_All.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        g.add_edge(row[0],row[1])
        print(g.node[row[0]])
        print("-----------------")
        print(g.node[row[1]])

# draw network
#nx.draw_networkx(g, with_labels=False, node_size=50, node_color='r')
#plt.show()

print "-----------------------DONE CREATING GRAPH -----------------------"

np.random.seed(0) # make sure train-test split is consistent between notebooks
adj_sparse = nx.to_scipy_sparse_matrix(g)

# Perform train-test split
adj_train, train_edges, train_edges_false, val_edges, val_edges_false, \
    test_edges, test_edges_false = mask_test_edges(adj_sparse, test_frac=.2, val_frac=.1)
g_train = nx.from_scipy_sparse_matrix(adj_train) # new graph object with only non-hidden edges

# Inspect train/test split
print "Total nodes:", adj_sparse.shape[0]
print "Total edges:", int(adj_sparse.nnz/2) # adj is symmetric, so nnz (num non-zero) = 2*num_edges
print "Training edges (positive):", len(train_edges)
print "Training edges (negative):", len(train_edges_false)
print "Validation edges (positive):", len(val_edges)
print "Validation edges (negative):", len(val_edges_false)
print "Test edges (positive):", len(test_edges)
print "Test edges (negative):", len(test_edges_false)

# node2vec settings
# NOTE: When p = q = 1, this is equivalent to DeepWalk

P = 1 # Return hyperparameter
Q = 1 # In-out hyperparameter
WINDOW_SIZE = 10 # Context size for optimization
NUM_WALKS = 10 # Number of walks per source
WALK_LENGTH = 80 # Length of walk per source
DIMENSIONS = 128 # Embedding dimension
DIRECTED = False # Graph directed/undirected
WORKERS = 8 # Num. parallel workers
ITER = 1 # SGD epochs

# Preprocessing, generate walks
g_n2v = node2vec.Graph(g_train, DIRECTED, P, Q) # create node2vec graph instance
g_n2v.preprocess_transition_probs()
walks = g_n2v.simulate_walks(NUM_WALKS, WALK_LENGTH)
walks = [map(str, walk) for walk in walks]

# Train skip-gram model
model = Word2Vec(walks, size=DIMENSIONS, window=WINDOW_SIZE, min_count=0, sg=1, workers=WORKERS, iter=ITER)

# Store embeddings mapping
emb_mappings = model.wv

print "-----------------------TRAINING NODE2VEC COMPLETE-----------------------"
print "-----------------------CREATING EDGE EMBEDDINGS-----------------------"

# Create node embeddings matrix (rows = nodes, columns = embedding features)
emb_list = []
for node_index in range(0, adj_sparse.shape[0]):
    node_str = str(node_index)
#    print "Node_str",str(node_index)
    node_emb = emb_mappings[node_str]
#    print "Node_emb",np.shape(node_emb)
    emb_list.append(node_emb)
emb_matrix = np.vstack(emb_list)

# Generate bootstrapped edge embeddings (as is done in node2vec paper)
    # Edge embedding for (v1, v2) = hadamard product of node embeddings for v1, v2
def get_edge_embeddings(edge_list):
    embs = []
    for edge in edge_list:
        node1 = edge[0]
        node2 = edge[1]
        emb1 = emb_matrix[node1]
        emb2 = emb_matrix[node2]
        edge_emb = np.multiply(emb1, emb2)
        embs.append(edge_emb)
    embs = np.array(embs)
    return embs

# Train-set edge embeddings
pos_train_edge_embs = get_edge_embeddings(train_edges)
neg_train_edge_embs = get_edge_embeddings(train_edges_false)
train_edge_embs = np.concatenate([pos_train_edge_embs, neg_train_edge_embs])

# Create train-set edge labels: 1 = real edge, 0 = false edge
train_edge_labels = np.concatenate([np.ones(len(train_edges)), np.zeros(len(train_edges_false))])

# Val-set edge embeddings, labels
pos_val_edge_embs = get_edge_embeddings(val_edges)
neg_val_edge_embs = get_edge_embeddings(val_edges_false)
val_edge_embs = np.concatenate([pos_val_edge_embs, neg_val_edge_embs])
val_edge_labels = np.concatenate([np.ones(len(val_edges)), np.zeros(len(val_edges_false))])

# Test-set edge embeddings, labels
pos_test_edge_embs = get_edge_embeddings(test_edges)
neg_test_edge_embs = get_edge_embeddings(test_edges_false)
test_edge_embs = np.concatenate([pos_test_edge_embs, neg_test_edge_embs])

# Create val-set edge labels: 1 = real edge, 0 = false edge
test_edge_labels = np.concatenate([np.ones(len(test_edges)), np.zeros(len(test_edges_false))])

print "----------------------- EDGE EMBEDDINGS CREATED -----------------------"

# Train logistic regression classifier on train-set edge embeddings
from sklearn.linear_model import LogisticRegression
edge_classifier = LogisticRegression(random_state=0)
edge_classifier.fit(train_edge_embs, train_edge_labels)

# Predicted edge scores: probability of being of class "1" (real edge)
val_preds = edge_classifier.predict_proba(val_edge_embs)[:, 1]
val_roc = roc_auc_score(val_edge_labels, val_preds)
val_ap = average_precision_score(val_edge_labels, val_preds)
val_f1 = f1_score(val_edge_labels, val_preds.round())
val_precision = precision_score(val_edge_labels, val_preds.round())
val_recall = recall_score(val_edge_labels, val_preds.round())

# Predicted edge scores: probability of being of class "1" (real edge)
test_preds = edge_classifier.predict_proba(test_edge_embs)[:, 1]
test_roc = roc_auc_score(test_edge_labels, test_preds)
test_ap = average_precision_score(test_edge_labels, test_preds)
test_f1 = f1_score(test_edge_labels, test_preds.round())
test_precision = precision_score(test_edge_labels, test_preds.round())
test_recall = recall_score(test_edge_labels, test_preds.round())


print 'node2vec Validation ROC score: ', str(val_roc)
print 'node2vec Validation AP score: ', str(val_ap)
print 'node2vec Validation Precision score: ', str(val_precision)
print 'node2vec Validation Recall score: ', str(val_recall)
print 'node2vec Validation F1 score: ', str(val_f1)

print 'node2vec Test ROC score: ', str(test_roc)
print 'node2vec Test AP score: ', str(test_ap)
print 'node2vec Test Precision score: ', str(test_precision)
print 'node2vec Test Recall score: ', str(test_recall)
print 'node2vec Test F1 score: ', str(test_f1)
