import networkx as nx
import csv
import matplotlib.pyplot as plt
'''
G=nx.Graph()
G.add_node(1)
G.add_node(2)
G.add_node(3)
G.add_edge(1,2)
nx.draw_networkx(G, with_labels=False, node_size=50, node_color='r')
plt.show()
'''
g = nx.Graph() # re-create graph using node indices (0 to num_nodes-1)

with open ('Nodes_Relatives.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        g.add_node(row[0],open = row[1],conscient = row[2],extrovert = row[3],agree = row[4],neurotic = row[5],
        	ach = row[6], ben = row[7], con = row[8], hed = row[9], pow = row[10], sec = row[11], sd =row[12],
        	sti = row[13], tra = row[14], uni = row[15], male = row[16], female = row[17], a_10 = row[18],
        	a_20 = row[19], a_30 = row[20])

with open ('Network_Relatives_All.csv','r') as f:
    reader = csv.reader(f,delimiter = ',')
    for row in reader:
        g.add_edge(row[0],row[1])
        print(g.node[row[0]])
        print("-----------------")
        print(g.node[row[1]])

